

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot

