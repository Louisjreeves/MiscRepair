﻿# In-Place Recovery Checker
$TotalFootprintOnPool=((get-VirtualDisk|?{$_.AllocatedSize -gt 0}|Select FootprintOnPool).FootprintOnPool| Measure-Object -sum).sum
$StoragePoolSize=(Get-StoragePool "S2D*" | Select size).size
$ReadableStoragePoolSize=[math]::Round($StoragePoolSize/1TB,2)
$FreeSpaceInStoragePool=($StoragePoolSize-$TotalFootprintOnPool)
$ReadableFreeSpaceInStoragePool=[Math]::Round($FreeSpaceInStoragePool/1TB,2)
$ClusterNodes=Get-ClusterNode
$SizeOfLargestDisk=(Get-PhysicalDisk | Where {$_.usage -match 'Auto-Select' -or $_.usage -match 1} | sort Size -Descending | Select Size -first 1 ).size
$ReadableSizeOfLargestDisk=[Math]::Round($SizeOfLargestDisk/1TB,2)
$InPlaceRepairFreeSpaceNeededInStoragePool=IF(($ClusterNodes|Measure-Object).count -ge 4){$SizeOfLargestDisk*4}Else{($SizeOfLargestDisk*($ClusterNodes|Measure-Object).count)}
$ReadableInPlaceRepairFreeSpaceNeededInStoragePool = [math]::round($InPlaceRepairFreeSpaceNeededInStoragePool/1TB,2)
$NumberofAutoRepairDisks=$InPlaceRepairFreeSpaceNeededInStoragePool/$SizeOfLargestDisk
IF($FreeSpaceInStoragePool -le $InPlaceRepairFreeSpaceNeededInStoragePool){Write-Host "More Space Needed for Auto Repair"}
CLS
Write-Host "In-Place Recovery Checker"
Write-Host "------------------------------------------------------"
Write-Host "Storage Pool Size:                    $ReadableStoragePoolSize TiB"
IF($FreeSpaceInStoragePool -le $InPlaceRepairFreeSpaceNeededInStoragePool){
    Write-Host "Storage Pool Free Space:              $ReadableFreeSpaceInStoragePool TiB" -ForegroundColor Red
    Write-Host "    ERROR: Not enough Reserve Capacity in Storage Pool." -ForegroundColor Red
    Write-Host "    Ref: https://docs.microsoft.com/en-us/windows-server/storage/storage-spaces/plan-volumes#reserve-capacity" -ForegroundColor Red
}Else{Write-Host "Storage Pool Free Space:              $ReadableFreeSpaceInStoragePool TiB" -ForegroundColor Green}
Write-Host "Largest Disk in Storage Pool:         $ReadableSizeOfLargestDisk TiB"
Write-Host "Disks Needed for In-Place Recovery:   $NumberofAutoRepairDisks" 
Write-Host "Space Required for In-Place Recovery: $ReadableInPlaceRepairFreeSpaceNeededInStoragePool TiB"
IF($FreeSpaceInStoragePool -le $InPlaceRepairFreeSpaceNeededInStoragePool){Write-Host "Able To In-Place Recover:             No" -ForegroundColor Red}Else{Write-Host "Able To In-Place Recover:             Yes" -ForegroundColor Green}