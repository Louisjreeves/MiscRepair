﻿Write-Host "    Gathering Support Matrix for Dell EMC Solutions for Microsoft Azure Stack HCI..."
$SMURL='https://www.dell.com/support/kbdoc/en-us/000126014/support-matrix-for-dell-emc-solutions-for-microsoft-azure-stack-hci'
$SMRequest = Invoke-WebRequest -Uri $SMURL
# All tables
$SMFWDRVRTable=$SMRequest.ParsedHtml.IHTMLDocument3_documentElement.getElementsByTagName("table")| Where-Object {$_.innerText -imatch 'SOFTWARE BUNDLE'}
$SMFWDRVRSoftwareBundles =@()
# Loop thru all tables for SOFTWARE BUNDLE values
    ForEach ($Table in $SMFWDRVRTable){
    $SOFTWAREBUNDLECol=-2
    #Find the column number or array index of SOFTWARE BUNDLE
        $b=$Table.tHead.rows | ?{$_.innertext -imatch 'SOFTWARE BUNDLE'} | select -ExpandProperty innertext
        ForEach($header in $b){
            $harr=($header -split '\n')
            $SOFTWAREBUNDLECol=(0..($harr.Count-1)) | where {$harr[$_] -imatch 'SOFTWARE BUNDLE'}
        }
    #Find the column number or array index of Model/Componet
        $CompModCol=-2
        $m=$Table.tHead.rows | ?{($_.innertext -imatch 'COMPONENT' -or $_.innertext -imatch 'MODEL')} | select -ExpandProperty innertext
        ForEach($header in $m){
            $harr=($header -split '\n')
            $CompModCol=(0..($harr.Count-1)) | where {($harr[$_]  -imatch 'COMPONENT' -or $harr[$_]  -imatch 'MODEL')}
        }

    # Finds the SOFTWARE BUNDLE values from all tables
    ForEach($Row in $Table.rows){
        $Cells = @($Row.Cells)
        $resultObject=@()
        IF($SOFTWAREBUNDLECol.Count -eq 1){
            #IF(($Cells.innerText[[int]($SOFTWAREBUNDLECol[-1]/2)]).Contains("MPXXJ")){pause}
            ForEach($C in [regex]::matches(($Cells.innerText[[int]($SOFTWAREBUNDLECol[-1]/2)]),'[A-Z,0-9]{5}').value){
                $resultObject = [PSCustomObject] @{
                                Title          = (($Cells.innerText[[int]($CompModCol[-1]/2)] -replace '^\s+','') -split '\n')[0]
                                SOFTWAREBUNDLE = $c
                }
            $SMFWDRVRSoftwareBundles += $resultObject 
            }
        }
    }
}
$SMFWDRVRSoftwareBundles = $SMFWDRVRSoftwareBundles| sort SOFTWAREBUNDLE -Unique
$SMFWDRVRSoftwareBundlesOS=@()
$SMFWDRVRTable=$SMRequest.ParsedHtml.IHTMLDocument3_documentElement.getElementsByTagName("table")| Where-Object {$_.innerText -imatch 'Mellanox'}
#2016 and newer fw bundles
    ForEach($Row in $SMFWDRVRTable[0].rows){
        #$resultObject
        #$SOFTWAREBUNDLECol
        #2016 or newer firware bundles
        $Cells = @($Row.Cells)
        $resultObject=@()
            ForEach($C3 in [regex]::matches($Cells.innerText[3],'[A-Z,0-9]{5}').value){
                $resultObject = [PSCustomObject] @{
                    Title      = (($Cells.innerText[0] -replace '^\s+','') -split '\n')[0]
                    SOFTWAREBUNDLE = $C3 -replace '^\s+',''
                }
                $SMFWDRVRSoftwareBundlesOS+= $resultObject
            }
}
#2019 or newer driver bundles
    ForEach($Row in $SMFWDRVRTable[1].rows){    
        $Cells = @($Row.Cells)
        $resultObject=@()
        #IF(($Cells.innerText[5]).Contains("VCDT1")){pause}
        ForEach($C5 in [regex]::matches($Cells.innerText[5],'[A-Z,0-9]{5}').value){
            $resultObject = [PSCustomObject] @{
                Title      = (($Cells.innerText[0] -replace '^\s+','') -split '\n')[0]
                SOFTWAREBUNDLE = $C5 -Replace "`r`n"," " -replace "\s\s"," " -replace '^\s+',''
            }
            $SMFWDRVRSoftwareBundlesOS+= $resultObject
        }
}

$SMFWDRVRSoftwareBundlesOS=$SMFWDRVRSoftwareBundlesOS | sort SOFTWAREBUNDLE -Unique 

$SMFWDRVRSoftwareBundlesAll=$SMFWDRVRSoftwareBundles + $SMFWDRVRSoftwareBundlesOS

# Used to extract .gz files
Function DeGZip-File{
    Param(
        $infile
        )
    $outFile = $infile.Substring(0, $infile.LastIndexOfAny('.'))
    $input = New-Object System.IO.FileStream $inFile, ([IO.FileMode]::Open), ([IO.FileAccess]::Read), ([IO.FileShare]::Read)
    $output = New-Object System.IO.FileStream $outFile, ([IO.FileMode]::Create), ([IO.FileAccess]::Write), ([IO.FileShare]::None)
    $gzipStream = New-Object System.IO.Compression.GzipStream $input, ([IO.Compression.CompressionMode]::Decompress)

    $buffer = New-Object byte[](1024)
    while($true){
        $read = $gzipstream.Read($buffer, 0, 1024)
        if ($read -le 0){break}
        $output.Write($buffer, 0, $read)
        }

    $gzipStream.Close()
    $output.Close()
    $input.Close()
}

#Get the AZHCI-Catalog
    $AzHCICatalogSource="https://dl.dell.com/catalog/ASHCI-Catalog.xml.gz"
    Invoke-WebRequest $AzHCICatalogSource -OutFile "$env:TEMP\ASHCI-Catalog.xml.gz" -UseDefaultCredentials
    #Extract AZHCI-Catalog.gz
        $infile="$($env:TEMP)\ASHCI-Catalog.xml.gz"
        DeGZip-File $infile
    #import the AzHCI XML
        Write-host "Importing ASHCI-Catalog.xml...."
        $AzHCICatalogSource = [Xml] (Get-Content "$env:TEMP\ASHCI-Catalog.xml")
        $AzHCICatalogSoftwareBundles=$AzHCICatalogSource.Manifest.SoftwareComponent.packageID | sort -Unique

#Get the Enterprise Catalog
    $CatalogSource="https://dl.dell.com/catalog/Catalog.gz"
    Invoke-WebRequest $CatalogSource -OutFile "$env:TEMP\Catalog.xml.gz" -UseDefaultCredentials
    #Extract Catalog.gz
        $infile="$($env:TEMP)\Catalog.xml.gz"
        DeGZip-File $infile
    #import the Catalog XML
        Write-host "Importing Catalog.xml...."
        $ECatalogSource = [Xml] (Get-Content "$env:TEMP\Catalog.xml")
        $ECatalogSourceSoftwareBundles=$ECatalogSource.Manifest.SoftwareComponent.packageID | sort -Unique

# Check for bundles in catalogs
    $WhichCatalog=@()
    ForEach($SMBun in $SMFWDRVRSoftwareBundlesAll){
        $WhichCatalog += [PSCustomObject] @{
                        'Description'     = $SMBun.Title
                        'SoftwareBundle'  = $SMBun.SOFTWAREBUNDLE
                        'ASHCI-Catalog'   = ($AzHCICatalogSoftwareBundles.contains($SMBun.SOFTWAREBUNDLE))
                        'Catalog'         = ($ECatalogSourceSoftwareBundles.contains($SMBun.SOFTWAREBUNDLE))
                        'Neither'         = ((-not($AzHCICatalogSoftwareBundles.contains($SMBun.SOFTWAREBUNDLE))) -and (-not($ECatalogSourceSoftwareBundles.contains($SMBun.SOFTWAREBUNDLE))))
                        }
    }

#Need attension
    $Needsattention= $WhichCatalog | sort 'ASHCI-Catalog',Catalog | ?{(-not($_.'ASHCI-Catalog' -eq $true -and $_.Catalog -eq $true))}
    $Needsattention | sort Description
    #$Needsattention | sort Description |Export-Csv -Path "C:\Users\JIM_GA~1\AppData\Local\Temp\Needsattention.CSV"
    $Needsattention.count
