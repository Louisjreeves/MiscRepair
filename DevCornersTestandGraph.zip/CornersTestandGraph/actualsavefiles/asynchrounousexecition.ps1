﻿#asyncrounous exection 


# Define the scriptblock for the performance tests
$TestScriptBlock = {
    # Your existing performance test code goes here
    # ...

    # Instead of Write-Host, collect the output in a variable
    $testOutput = "Test $Counter, $Disk, $IO, $type, $Blocks, Run $_, $iops iops, $mbps MB/sec, $latency ms, $cpu CPU"

    # Output the collected data to a file
    Add-Content -Path ./output.txt -Value $testOutput
}

# Define the number of tests
$NumberOfTests = 4

# Initialize a counter
$counter = 0

# Loop to start the tests asynchronously
do {
    $job = Start-Job -ScriptBlock $TestScriptBlock

    # Increment the counter
    $counter++

    # Calculate the percentage completed based on the total number of tests and the current counter value
    $percentComplete = [Math]::Round(($counter / $NumberOfTests) * 100)

    # Show progress
    Write-Progress -Activity "Performing Tests" -Status "Test $counter of $NumberOfTests" -PercentComplete $percentComplete

} while ($counter -lt $NumberOfTests)

# Wait for all jobs to finish
Get-Job | Wait-Job | Out-Null

# Remove the jobs
Remove-Job *

# Show completion message
Write-Progress -Activity "Performing Tests" -Completed
Write-Host "Testing is complete. You may have to restart the application and choose the Open Graph Button."
