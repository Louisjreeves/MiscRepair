﻿ 
 $global:disk = "E:"

# the format has to be just like below
# Test N#	 Drive	 Operation	 Access	 Blocks	 Run N#	 IOPS	 MB/sec	 Latency ms	 CPU %
# place the numbers in the csv as csv or space seperated values 

# set path asap 
$mypath = $MyInvocation.MyCommand.path
$mydir = split-path $mypath -Parent

Set-Location -Path $mydir

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
Set-Location  "$mydownloads\CornersTestandGraph\"
$mydir = $pwd
Clear-Host
#Write-host "The CSV file needs to be in this folder. It also must be in the proper format like the dat.csv"
#write-host "Failure to do those things will result in you getting nothing valuable from this forray" -BackgroundColor Green
#$keypressed = "dat.csv"
#$keybus = Read-host "enter the name of the file you want me to do your work for you on. Enter=dat.csv"

#if ([bool] $keybus -eq $true) {$keypressed = $keybus} else {$keypressed = "dat.csv"}
 
 if (test-path -Path output.txt) {
  
    if (test-path -Path dat.csv) {
     Rename-Item -Path dat.csv -NewName dat.old -force
     Rename-Item -Path output.txt -NewName dat.csv -force
     }
  
  }

Add-Type -AssemblyName System.Windows.Forms
 Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Windows.Forms.DataVisualization
 
 

# Load the data from a CSV file
$data = Import-Csv -Path "$mydir\dat.csv"

# Filter the data to include only rows where the Operation column contains "Read"
$read_data = $data | Where-Object { $_.Operation -like "*Read*" }


# Split the data into two sets based on the Access column
$read_random_access_data = $read_data | Where-Object { $_.Access -like "*Random*" }
$read_sequential_access_data = $read_data | Where-Object { $_.Access -like "*Sequential*" }

#########test random read and sequential read data 
$read_random_access_data | ft
$read_sequential_access_data | ft

# Combine the two sets of data and create a new property to identify the access type
$read_combined_ran = $read_random_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Read_combined_seq = $read_sequential_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

##### FILTER THE DATA FOR WRITE DATA 
# Filter the data to include only rows where the Operation column contains "Write"
 $write_data = $data | Where-Object { $_.Operation -like "*Write*" }

# Split the data into two sets based on the Access column
$random_write_access_data = $write_data | Where-Object { $_.Access -like "Random" }
$sequential_write_access_data = $write_data | Where-Object { $_.Access -like "Sequential" }

# Combine the two sets of data and create a new property to identify the access type
$write_combined_ran = $random_write_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Write_combined_seq = $sequential_write_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

#### test random and sequentual writes 
#$write_combined_ran | ft
#$Write_combined_seq | ft
$random_write_access_data | ft
$sequential_write_access_data | ft


#### FINISH FILTER FOR WRITE DATA 
# Calculate the maximum Y-value for all data points
# Find the largest value for IOPS in each dataset
$maxIOPS_read_ran = $read_combined_ran.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_read_seq = $Read_combined_seq.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_write_ran = $write_combined_ran.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_write_seq = $Write_combined_seq.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

# Find the largest value for MB/sec in each dataset
$maxMBSec_read_seq = $Read_combined_seq."MB/sec" | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxMBSec_write_seq = $Write_combined_seq."MB/sec" | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

# the format has to be just like below
# Test N#	 Drive	 Operation	 Access	 Blocks	 Run N#	 IOPS	 MB/sec	 Latency ms	 CPU %
# place the numbers in the csv as csv or space seperated values 

# set path asap 
$mypath = $MyInvocation.MyCommand.path
$mydir = split-path $mypath -Parent

Set-Location -Path $mydir

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
Set-Location  "$mydownloads\CornersTestandGraph\"
$mydir = $pwd
Clear-Host
#Write-host "The CSV file needs to be in this folder. It also must be in the proper format like the dat.csv"
#write-host "Failure to do those things will result in you getting nothing valuable from this forray" -BackgroundColor Green
#$keypressed = "dat.csv"
#$keybus = Read-host "enter the name of the file you want me to do your work for you on. Enter=dat.csv"

#if ([bool] $keybus -eq $true) {$keypressed = $keybus} else {$keypressed = "dat.csv"}
 
 if (test-path -Path output.txt) {
  
    if (test-path -Path dat.csv) {
     Rename-Item -Path dat.csv -NewName dat.old -force
     Rename-Item -Path output.txt -NewName dat.csv -force
     }
  
  }

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Windows.Forms.DataVisualization
 
# Load the data from a CSV file
$data = Import-Csv -Path "$mydir\dat.csv"

# Filter the data to include only rows where the Operation column contains "Read"
$read_data = $data | Where-Object { $_.Operation -like "*Read*" }


# Split the data into two sets based on the Access column
$read_random_access_data = $read_data | Where-Object { $_.Access -like "*Random*" }
$read_sequential_access_data = $read_data | Where-Object { $_.Access -like "*Sequential*" }

#########test random read and sequential read data 
$read_random_access_data | ft
$read_sequential_access_data | ft

# Combine the two sets of data and create a new property to identify the access type
$read_combined_ran = $read_random_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Read_combined_seq = $read_sequential_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

##### FILTER THE DATA FOR WRITE DATA 
# Filter the data to include only rows where the Operation column contains "Write"
 $write_data = $data | Where-Object { $_.Operation -like "*Write*" }

# Split the data into two sets based on the Access column
$random_write_access_data = $write_data | Where-Object { $_.Access -like "Random" }
$sequential_write_access_data = $write_data | Where-Object { $_.Access -like "Sequential" }

# Combine the two sets of data and create a new property to identify the access type
$write_combined_ran = $random_write_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Write_combined_seq = $sequential_write_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

#### test random and sequentual writes 
#$write_combined_ran | ft
#$Write_combined_seq | ft
$random_write_access_data | ft
$sequential_write_access_data | ft


#### FINISH FILTER FOR WRITE DATA 
# Calculate the maximum Y-value for all data points
# Find the largest value for IOPS in each dataset
$maxIOPS_read_ran = $read_combined_ran.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_read_seq = $Read_combined_seq.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_write_ran = $write_combined_ran.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxIOPS_write_seq = $Write_combined_seq.IOPS | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

# Find the largest value for MB/sec in each dataset
$maxMBSec_read_seq = $Read_combined_seq."MB/sec" | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxMBSec_write_seq = $Write_combined_seq."MB/sec" | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$global:form = New-Object System.Windows.Forms.Form

# Calculate the maximum Y-value by finding the largest value among all datasets
$maxYValue = ($maxIOPS_read_ran, $maxIOPS_read_seq, $maxIOPS_write_ran, $maxIOPS_write_seq) | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxY2Value = ($maxMBSec_read_seq, $maxMBSec_write_seq) | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

# Create the graph
$chart = New-Object System.Windows.Forms.DataVisualization.Charting.Chart
$chart.Width = 800
$chart.Height = 600

$chartArea = New-Object System.Windows.Forms.DataVisualization.Charting.ChartArea
$chart.ChartAreas.Add($chartArea)

$legend = New-Object System.Windows.Forms.DataVisualization.Charting.Legend
$legend.Docking = "bottom"
$chart.Legends.Add($legend)

$dataSeries1 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries1.Name = "Random Read"
$dataSeries1.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries1.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries1.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries1.BorderWidth = 2
$dataSeries1.Color = [System.Drawing.Color]::Blue

$dataSeries2 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries2.Name = "Sequential Read"
$dataSeries2.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries2.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries2.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries2.BorderWidth = 2
$dataSeries2.Color = [System.Drawing.Color]::Yellow
$dataSeries2.YAxisType = [System.Windows.Forms.DataVisualization.Charting.AxisType]::Secondary  # Set YAxisType to Secondary

$dataSeries11 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries11.Name = "Random Write"
$dataSeries11.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries11.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries11.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries11.BorderWidth = 2
$dataSeries11.Color = [System.Drawing.Color]::Green

$dataSeries21 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries21.Name = "Sequential Write"
$dataSeries21.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries21.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries21.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries21.BorderWidth = 2
$dataSeries21.Color = [System.Drawing.Color]::DarkMagenta
$dataSeries21.YAxisType = [System.Windows.Forms.DataVisualization.Charting.AxisType]::Secondary  # Set YAxisType to Secondary

# Create the first Y-axis
$yAxis1 = $chart.ChartAreas[0].AxisY
$yAxis1.Title = "IOPS"
$yAxis1.MajorGrid.Enabled = $false
$yAxis1.LabelStyle.Format = "0"
$yAxis1.Maximum = $maxYValue

# Create the second Y-axis
$yAxis2 = $chart.ChartAreas[0].AxisY2
$yAxis2.Title = "MB/sec"
$yAxis2.MajorGrid.Enabled = $false
$yAxis2.LabelStyle.Format = "0"
$yAxis2.Maximum = $maxY2Value

$ChartTitle = New-Object System.Windows.Forms.DataVisualization.Charting.Title
$ChartTitle.Text = 'Sequential =Mb/Sec (green,red) / IO = IOPS counts (blue,pink)'
$Font = New-Object System.Drawing.Font @('Microsoft Sans Serif','12', [System.Drawing.FontStyle]::Bold)
$ChartTitle.Font =$Font
$Chart.Titles.Add($ChartTitle)


foreach ($item in $read_combined_ran) {
    $blocks= $item."blocks"
    $access = $item.Access
    #$mb_sec = $item."MB/sec"
    $iops = $item.IOPS
    
    if ($access -eq "Random") {
        $dataSeries1.Points.AddXY($Blocks,$iops)
    } 
}
 
foreach ($item in $Read_combined_seq) {
    $access = $item.Access
    $mb_sec = $item."MB/sec"
    $blocks = $item."Blocks"
   # $iops = $item.IOPS

    if ($access -like "Sequential") {
        $dataSeries2.Points.AddXY($blocks, $mb_sec)
    }
        
   
}

foreach ($item in $write_combined_ran) {
    $access = $item.Access
    $iops = $item.IOPS
    $blocks = $item."Blocks"

    if ($access -eq "Random") {
        $dataSeries11.Points.AddXY($Blocks, $iops)
    }
}

foreach ($item in $Write_combined_seq) {
    $access = $item.Access
    $mb_sec = $item."MB/sec"
    $blocks = $item."Blocks"
    if ($access -eq "Sequential") {
        Write-Host "Adding sequential write data point: Blocks=$blocks, MB/sec=$mb_sec"
        $dataSeries21.Points.AddXY($Blocks, $mb_sec)
    }
}


$chart.Series.Add($dataSeries1)
$chart.Series.Add($dataSeries2)

$chart.Series.Add($dataSeries11)
$chart.Series.Add($dataSeries21)

$chart.SaveImage("$mydir\graph.png", [System.Drawing.Imaging.ImageFormat]::Png)
#$combined_data | ConvertTo-Json | Out-File "$mydir\data.json" -Append
$read_combined_ran | ConvertTo-Json | Out-File "$mydir\data.json" -Append
$Read_combined_seq | ConvertTo-Json | Out-File "$mydir\data.json" -Append
$write_combined_ran | ConvertTo-Json | Out-File "$mydir\data.json" -Append
$Write_combined_seq | ConvertTo-Json | Out-File "$mydir\data.json" -Append


## Rule For Sequential IO - THROUGHPUT Don’t worry about the IO- Only the throughput matters
### Rule	For Random IO- Only IOPS matters- don’t worry about throughput 



$chartForm = New-Object System.Windows.Forms.Form
$chartForm.SuspendLayout()
$chart.Dock = [System.Windows.Forms.DockStyle]::Fill
$chartForm.Controls.Add($chart)
$chartForm.ResumeLayout()



 


# Show the form
$chartForm.ShowDialog()





