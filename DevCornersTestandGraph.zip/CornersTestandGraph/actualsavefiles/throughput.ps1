﻿ 
# the format has to be just like below
# Test N#	 Drive	 Operation	 Access	 Blocks	 Run N#	 IOPS	 MB/sec	 Latency ms	 CPU %
# place the numbers in the csv as csv or space seperated values 


# set path asap 
$mypath = $MyInvocation.MyCommand.path
$mydir = split-path $mypath -Parent

Set-Location -Path $mydir

 

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
Set-Location  "$mydownloads\CornersTestandGraph\"

  if (test-path -Path output.txt) { Rename-Item -Path output.txt -NewName dat.csv}



Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Windows.Forms.DataVisualization
 Add-Type -AssemblyName System.Drawing

 
# Load the data from a CSV file
$data = Import-Csv -Path "$mydir\dat.csv"




# Filter the data to include only rows where the Operation column contains "Read"
$read_data = $data | Where-Object { $_.Operation -like "*Read*" }


# Split the data into two sets based on the Access column
#$read_random_access_data = $read_data | Where-Object { $_.Access -like "*Random*" }
$read_sequential_access_data = $read_data | Where-Object { $_.Access -like "*Sequential*" }

#########test random read and sequential read data 
$read_random_access_data | ft
$read_sequential_access_data | ft

# Combine the two sets of data and create a new property to identify the access type
#$read_combined_ran = $read_random_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Read_combined_seq = $read_sequential_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

##### FILTER THE DATA FOR WRITE DATA 
# Filter the data to include only rows where the Operation column contains "Write"
 $write_data = $data | Where-Object { $_.Operation -like "*Write*" }

# Split the data into two sets based on the Access column
#$random_write_access_data = $write_data | Where-Object { $_.Access -like "Random" }
$sequential_write_access_data = $write_data | Where-Object { $_.Access -like "Sequential" }

# Combine the two sets of data and create a new property to identify the access type
#$write_combined_ran = $random_write_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Write_combined_seq = $sequential_write_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

# Find the largest value for MB/sec in each dataset
 

# Find the largest value for MB/sec in each dataset
$maxMBSec_read_seq = $Read_combined_seq | ForEach-Object { [double]$_.("MB/sec") } | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
$maxMBSec_write_seq = $Write_combined_seq | ForEach-Object { [double]$_.("MB/sec") } | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum


#### test random and sequentual writes 
#$write_combined_ran | ft
#$Write_combined_seq | ft
#$random_write_access_data | ft
$sequential_write_access_data | ft


#### FINISH FILTER FOR WRITE DATA 
$maxY2Value = ($maxMBSec_read_seq, $maxMBSec_write_seq) | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum


# Create the graph
$chart = New-Object System.Windows.Forms.DataVisualization.Charting.Chart
$chart.Width = 800
$chart.Height = 600

$chartArea = New-Object System.Windows.Forms.DataVisualization.Charting.ChartArea
$chart.ChartAreas.Add($chartArea)

$legend = New-Object System.Windows.Forms.DataVisualization.Charting.Legend
$legend.Docking = "bottom"
$chart.Legends.Add($legend)

$dataSeries2 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries2.Name = "Sequential Read"
$dataSeries2.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries2.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries2.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries2.BorderWidth = 2
$dataSeries2.Color = [System.Drawing.Color]::Yellow

$dataSeries21 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries21.Name = "Sequential Write"
$dataSeries21.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries21.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries21.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries21.BorderWidth = 2
$dataSeries21.Color = [System.Drawing.Color]::Green

# Create the Y-axis
$yAxis = $chart.ChartAreas[0].AxisY
$yAxis.Title = "MB/sec"
$yAxis.MajorGrid.Enabled = $false
$yAxis.LabelStyle.Format = "F2"  # Set format specifier to display up to two decimal places
$yAxis.Maximum = $maxY2Value

foreach ($item in $Read_combined_seq) {
    $access = $item.Access
    $mb_sec = $item."MB/sec"
    $blocks = $item.Blocks

    if ($access -like "Sequential") {
        $dataSeries2.Points.AddXY($blocks, $mb_sec)
    } 
}

foreach ($item in $Write_combined_seq) {
    $access = $item.Access
    $mb_sec = $item."MB/sec"
    $blocks = $item.Blocks

    if ($access -like "Sequential") {
        $dataSeries21.Points.AddXY($blocks, $mb_sec)
    }
}

$chart.Series.Add($dataSeries2)
$chart.Series.Add($dataSeries21)

$chart.SaveImage("$mydir\graphSequential_Throughput.png", [System.Drawing.Imaging.ImageFormat]::Png)
$Read_combined_seq | ConvertTo-Json | Out-File "$mydir\dataSEQ_mbPERsec.json" -Append
$Write_combined_seq | ConvertTo-Json | Out-File "dataSEQ_mbPERsec.json" -Append

# Show the form
$chartForm = New-Object System.Windows.Forms.Form
$chartForm.SuspendLayout()
$chart.Dock = [System.Windows.Forms.DockStyle]::Fill
$chartForm.Controls.Add($chart)
$chartForm.ResumeLayout()
$chartForm.ShowDialog()
