﻿# Load the necessary assemblies for creating runspaces
Add-Type -AssemblyName System.Threading
Add-Type -TypeDefinition @"
    using System.Management.Automation.Runspaces;
    public static class RunspaceFactoryHelper {
        public static Runspace CreateRunspace() {
            Runspace runspace = RunspaceFactory.CreateRunspace();
            runspace.Open();
            return runspace;
        }
    }
"@
$global:disk = "E:"

# Function to define the test scriptblock
function Get-TestScriptBlock {
    param($counter, $disk, $IO, $type, $blocks, $run, $iops, $mbps, $latency, $cpu)

  do {
    (4, 8, 64, 512) | ForEach-Object {
        $BlockParameter = ("-b" + $_ + "K")
        $Blocks = ("Blocks " + $_ + "K")

        # We will do Read tests and Write tests
        (0, 100) | ForEach-Object {
            if ($_ -eq 0) { $IO = "Read" }
            if ($_ -eq 100) { $IO = "Write" }
            $WriteParameter = "-w" + $_

            # We will do random and sequential IO tests
            ("r", "si") | ForEach-Object {
                if ($_ -eq "r") { $type = "Random" }
                if ($_ -eq "si") { $type = "Sequential" }
                $AccessParameter = "-" + $_

                # Each run will be done 4 times
                (1..1) | ForEach-Object {
                    # The test itself (finally!!)
                    $result = .\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $Disk\TestDiskSpd\testfile.dat

                    # Now we will break the very verbose output of DiskSpd in a single line with the most important values
                    foreach ($line in $result) { if ($line -like "*total:*") { $total = $line; break } }
                    foreach ($line in $result) { if ($line -like "*avg.*") { $avg = $line; break } }
                    $mbps = $total.Split("|")[2].Trim()
                    $iops = $total.Split("|")[3].Trim()
                    $latency = $total.Split("|")[4].Trim()
                    $cpu = $avg.Split("|")[1].Trim()
                    $counter = $counter + 1

                    # A progress bar, for the fun
                    Write-Progress -Activity ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $Disk\TestDiskSpd\testfile.dat" -status "Test in progress" -percentComplete ($counter / ($NumberofTests) * 100)    

                    # Remove comment to check command line ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread -$OutstandingIO $BlockParameter -h -L $Disk\TestDiskSpd\testfile.dat"
                    # We output the values to the text file
                $testcost.text =    "Test $Counter,$Disk,$IO,$type,$Blocks,Run $_,$iops,$mbps,$latency,$cpu"  
                
                   
               

               $output = "Test $Counter,$Disk,$IO,$type,$Blocks,Run $_,$iops,$mbps,$latency,$cpu"
                  Write-Output $output
                    Add-Content -Path ./output.txt -Value $output


                    # We output a verbose format on screen
               write-host "Test $Counter, $Disk, $IO, $type, $Blocks, Run $_, $iops iops, $mbps MB/sec, $latency ms, $cpu CPU"






                }

            }

        }

    }

    # Calculate the percentage completed based on the total number of tests and the current counter value
    $percentComplete = [Math]::Round(($counter / $NumberOfTests ) * 100)

} while ($counter -lt $NumberOfTests)

Write-Progress -Activity ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $Disk\TestDiskSpd\testfile.dat" -status "Ready" -Completed  
Write-host " Testing is complete. You may have to restart the application and chose the Open Graph Button."



    # Instead of Write-Host, collect the output in a variable
    $testOutput = "Test $counter, $disk, $IO, $type, $blocks, Run $run, $iops iops, $mbps MB/sec, $latency ms, $cpu CPU"

    # Output the collected data to a file
    Add-Content -Path ./output.txt -Value $testOutput
}

# Define the number of tests
$NumberOfTests = 4

# Initialize a counter
$counter = 0

# Create an array to store the runspaces
$runspaces = @()

# Loop to start the tests concurrently with multiple threads (runspaces)
do {
    # Increment the counter
    $counter++

    # Calculate the percentage completed based on the total number of tests and the current counter value
    $percentComplete = [Math]::Round(($counter / $NumberOfTests) * 100)

    # Show progress
    Write-Progress -Activity "Performing Tests" -Status "Test $counter of $NumberOfTests" -PercentComplete $percentComplete

    # Create and start a new runspace for each test
    $runspace = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
    $runspace.Open()

    # Create a new PowerShell instance within the runspace
    $powershell = [PowerShell]::Create()
    $powershell.Runspace = $runspace

    # Add the script block with parameters to the PowerShell instance
    $powershell.AddScript({
        param($counter, $disk, $IO, $type, $blocks, $run, $iops, $mbps, $latency, $cpu)

        # Invoke the function with the scriptblock containing the performance test code
        Get-TestScriptBlock $counter $disk $IO $type $blocks $run $iops $mbps $latency $cpu
    }) | Out-Null

    # Add parameters to the PowerShell instance
    $powershell.AddArgument($counter)
    $powershell.AddArgument $Disk
    $powershell.AddArgument $IO
    $powershell.AddArgument $type
    $powershell.AddArgument $Blocks
    $powershell.AddArgument $_
    $powershell.AddArgument $iops
    $powershell.AddArgument $mbps
    $powershell.AddArgument $latency
    $powershell.AddArgument $cpu

    # Start the asynchronous execution of the scriptblock within the runspace
    $runspaces += [pscustomobject]@{
        PowerShell = $powershell
        Handle = $powershell.BeginInvoke()
    }

} while ($counter -lt $NumberOfTests)

# Wait for all runspaces to finish
while ($runspaces.Handle -ne $null -and !$runspaces.Handle.IsCompleted) 
{
    write-host "still waiting"
    Start-Sleep -Milliseconds 100


}

# Close and remove runspaces
foreach ($r in $runspaces) {
    $r.PowerShell.EndInvoke($r.Handle)
    $r.PowerShell.Dispose()
    $r.PowerShell.Runspace.Close()
    $r.PowerShell.Runspace.Dispose()
}

# Show completion message
Write-Progress -Activity "Performing Tests" -Completed
Write-Host "Testing is complete. You may have to restart the application and choose the Open Graph Button."
###################################



# single job run 

# Function to define the test scriptblock
function Get-TestScriptBlock {
    param($counter, $disk, $IO, $type, $blocks, $run, $iops, $mbps, $latency, $cpu)

    # Your existing performance test code goes here
    # ...

    # Instead of Write-Host, collect the output in a variable
    $testOutput = "Test $counter, $disk, $IO, $type, $blocks, Run $run, $iops iops, $mbps MB/sec, $latency ms, $cpu CPU"

    # Output the collected data to a file
    Add-Content -Path ./output.txt -Value $testOutput
}

# Define the number of tests
$NumberOfTests = 4

# Initialize a counter
$counter = 0

# Loop to start the tests sequentially
do {
    # Increment the counter
    $counter++

    # Calculate the percentage completed based on the total number of tests and the current counter value
    $percentComplete = [Math]::Round(($counter / $NumberOfTests) * 100)

    # Show progress
    Write-Progress -Activity "Performing Tests" -Status "Test $counter of $NumberOfTests" -PercentComplete $percentComplete

    # Invoke the function with the scriptblock containing the performance test code
    Get-TestScriptBlock $counter $Disk $IO $type $Blocks $_ $iops $mbps $latency $cpu

} while ($counter -lt $NumberOfTests)

# Show completion message
Write-Progress -Activity "Performing Tests" -Completed
Write-Host "Testing is complete. You may have to restart the application and choose the Open Graph Button."
