﻿# Set the number of tests
$NumberOfTests = 16

# Rest of the script remains unchanged

# Begin Tests loops
# We will run the tests with 4K, 8K, 64K, and 512K blocks
(4, 8, 64, 512) | ForEach-Object {
    # Rest of the code remains unchanged
    # ...
    # ...

    # We will do Read tests and Write tests
    (0, 100) | ForEach-Object {
        # Rest of the code remains unchanged
        # ...
        # ...

        # We will do random and sequential IO tests
        ("r", "si") | ForEach-Object {
            # Rest of the code remains unchanged
            # ...
            # ...

            # Each run will be done 4 times
            (1..4) | ForEach-Object {
                # The test itself (finally !!)
                # Rest of the code remains unchanged
                # ...
                # ...

                # Increment the counter and check if we reached the desired number of tests
                $counter++
                if ($counter -ge $NumberOfTests) {
                    Write-Host "Test completed after $NumberOfTests tests."
                    return
                }
            }
        }
    }
}
