﻿ 

# Drive performance Report Generator
# Original by Arnaud TORRES, Edited by Hans Lenze Kaper on 25 - sep - 2015
$ErrorActionPreference = 'silentlycontinue'
$WarningPreference = 'silentlycontinue'
# Clear screen
Clear-host

write-host "DRIVE PERFORMANCE REPORT GENERATOR" -foregroundcolor green
write-host "Script will stress your computer CPU and storage layer (including network if applicable!), be sure that no critical workload is running" -foregroundcolor yellow

# Disk to test
$Disk = Read-Host 'Which path would you like to test? (example - C:\ClusterStorage\Volume1 or \\fileserver\share or S:) Without the trailing \'

# Set time in seconds for each run
# 10-120s is fine
$TimeInput = Read-Host 'Duration: How long should each run take in seconds? (example - 60)'
$Time = "-d" + $TimeInput

# Choose how big the benchmark file should be. Make sure it is at least two times the size of the available cache.
$capacity = Read-Host 'Testfile size: How big should the benchmark file be in GigaBytes? At least two times the cache size (example - 100)'
$CapacityParameter = "-c" + $Capacity + "G"

# Get date for the output file
$date = get-date
remove-item output.txt
# Add the tested disk and the date in the output file
"Command used for the runs .\diskspd.exe -c[testfileSize]G -d[duration] -[randomOrSequential] -w[%write] -t[NumberOfThreads] -o[queue] -b[blocksize] -h -L $Disk\DiskStress\testfile.dat, $date" >> ./output.txt

# Add the headers to the output file
"Test N#, Drive, Operation, Access, Blocks, QueueDepth, Run N#, IOPS, MB/sec, Latency ms, CPU %" >> ./output.txt

write-host "TEST RESULTS (also logged in .\output.txt)" -foregroundcolor yellow

# Begin Tests loops
$NumberOfTests = 16  # 4 tests (read random, read sequential, write random, write sequential) x 4 runs each

$QueueDepths = 1, 8, 16, 32
$BlockSizes = 4, 4, 4, 4   # 4k block size for all tests
$ReadWrite = 0, 0, 100, 100  # 0 for read, 100 for write
$RandomSequential = "r", "si", "r", "si"

for ($i = 0; $i -lt $NumberOfTests; $i++) {
    # Rest of the code remains the same

    # ...

    for ($run = 1; $run -le 4; $run++) {
        # Rest of the code remains the same

        # ...

        # We output the values to the text file
        "Test $Counter,$Disk,$IO,$type,$Blocks,$queue,Run $run,$iops,$mbps,$latency,$cpu" >> ./output.txt

        # We output a verbose format on screen
        "Test $Counter, $Disk, $IO, $type, $Blocks, $queue, Run $run, $iops iops, $mbps MB/sec, $latency ms, $cpu CPU"

        # Increment the counter here, only when a test is performed
        $counter++

        # A progress bar, for fun
        Write-Progress -Activity ".\diskspd.exe $CapacityParameter $Time $AccessParameter $WriteParameter -t1 $queueparameter $BlockParameter -h -L $Disk\TestDiskSpd\testfile.dat" -status "Test in progress" -percentComplete ($counter / $NumberOfTests * 100)

        # Check if we reached the desired number of tests
        if ($counter -ge $NumberOfTests) {
            Write-Host "Test completed after $NumberOfTests tests."
            break
        }
    }

    # Check if we reached the desired number of tests again to break out of the outer loop
    if ($counter -ge $NumberOfTests) {
        break
    }
}

 #here is the original https://www.kaperschip.nl/2017/06/easy-storage-benchmark-script-based-on.html