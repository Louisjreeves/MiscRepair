﻿# ...

write-host "TEST RESULTS (also logged in .\output.txt)" -foregroundcolor yellow

# Begin Tests loops
$NumberOfTests = 16  # 4 tests (read random, read sequential, write random, write sequential) x 4 runs each

$QueueDepths = 1, 8, 16, 32
$BlockSizes = 4, 4, 4, 4   # 4k block size for all tests
$ReadWrite = 0, 0, 100, 100  # 0 for read, 100 for write
$RandomSequential = "r", "si", "r", "si"

for ($i = 0; $i -lt $NumberOfTests; $i++) {
    # Rest of the code remains the same

    # ...

    for ($run = 1; $run -le 4; $run++) {
        # Rest of the code remains the same

        # ...

        $counter++

        # A progress bar, for fun
        Write-Progress -Activity ".\diskspd.exe $CapacityParameter $Time $AccessParameter $WriteParameter -t1 $queueparameter $BlockParameter -h -L $Disk\TestDiskSpd\testfile.dat" -status "Test in progress" -percentComplete ($counter / $NumberOfTests * 100)

        # We output the values to the text file
        "Test $Counter,$Disk,$IO,$type,$Blocks,$queue,Run $run,$iops,$mbps,$latency,$cpu" >> ./output.txt

        # We output a verbose format on screen
        "Test $Counter, $Disk, $IO, $type, $Blocks, $queue, Run $run, $iops iops, $mbps MB/sec, $latency ms, $cpu CPU"

        # Check if we reached the desired number of tests
        if ($counter -ge $NumberOfTests) {
            Write-Host "Test completed after $NumberOfTests tests."
            break
        }
    }

    # Check if we reached the desired number of tests again to break out of the outer loop
    if ($counter -ge $NumberOfTests) {
        break
    }
}
