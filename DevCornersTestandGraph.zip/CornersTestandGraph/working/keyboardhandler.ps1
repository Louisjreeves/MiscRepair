﻿# Import the required namespace for keyboard handling
Add-Type -TypeDefinition @'
    using System;
    using System.Windows.Forms;
    
    public class KeyboardHandler : IMessageFilter
    {
        private const int WM_KEYDOWN = 0x0100;
        private const int VK_ESCAPE = 0x1B;

        public bool PreFilterMessage(ref Message m)
        {
            if (m.Msg == WM_KEYDOWN && (int)m.WParam == VK_ESCAPE)
            {
                Application.Exit();
                return true;
            }
            return false;
        }
    }
'@

# Create an instance of the keyboard handler and add it as a message filter
$keyboardHandler = New-Object -TypeName KeyboardHandler
[System.Windows.Forms.Application]::AddMessageFilter($keyboardHandler)

# Function to start the diskspd test and update progress
function Start-DiskspdTest {
    # ... Your other code ...

    # Set $myvar1 to $null initially
    $myvar1 = $null

    while ($myvar1) {
        $myvar1 = Write-Progress -Activity ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat" -status "Test in progress" -percentComplete ($counter / $NumberofTests * 100)
        $timecost.Text = "Running: $myvar1"

        # Wait for 5 minutes before the next update
        Start-Sleep -Seconds (5 * 60)
    }

    # Remove the keyboard handler before exiting
    [System.Windows.Forms.Application]::RemoveMessageFilter($keyboardHandler)

    # Allow the form to remain open and functional after the loop finishes
    $Form.ShowDialog()
}

# Create the button control
$button = New-Object System.Windows.Forms.Button
$button.Text = "Start Diskspd Test"
$button.Location = New-Object System.Drawing.Point(10, 10)
$button.Size = New-Object System.Drawing.Size(120, 30)

# Add the Click event handler to the button
$button.Add_Click({
    Start-DiskspdTest
})

# Add the button control to the form
$Form.Controls.Add($button)

# ... Your other code ...
