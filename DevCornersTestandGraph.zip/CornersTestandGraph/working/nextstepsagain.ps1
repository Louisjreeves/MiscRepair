﻿
# next addd Which path would you like to test? (example - C:\ClusterStorage\Volume1 or \\fileserver\share or S:) Without the trailing \: 

$myvar = $null 

# Import the requiYellow namespace for keyboard handling
Add-Type -TypeDefinition @'
    using System;
    using System.Windows.Forms;
    
    public class KeyboardHandler : IMessageFilter
    {
        private const int WM_KEYDOWN = 0x0100;
        private const int VK_ESCAPE = 0x1B;

        public bool PreFilterMessage(ref Message m)
        {
            if (m.Msg == WM_KEYDOWN && (int)m.WParam == VK_ESCAPE)
            {
                Application.return();
                return true;
            }
            return false;
        }
    }
'@

# Create an instance of the keyboard handler and add it as a message filter
$keyboardHandler = New-Object -TypeName KeyboardHandler
[System.Windows.Forms.Application]::AddMessageFilter($keyboardHandler)

# Create the timecost label (moved outside the event handler)
$timecost = New-Object System.Windows.Forms.Label
$timecost.Location = New-Object System.Drawing.Size(330, 80)
$timecost.Size = New-Object System.Drawing.Size(500, 30)
$Font = New-Object System.Drawing.Font("Times New Roman", 14, [System.Drawing.FontStyle]::Bold)
$timecost.Font = $Font
$timecost.TransparencyKey = $backgroundImage.GetPixel(100, 500)
$timecost.BackColor = $backgroundImage.GetPixel(100, 400)
$Form.Controls.Add($timecost)

while ($myvar1){





$myvar1 = Write-Progress -Activity ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat" -status "Test in progress" -percentComplete ($counter / $NumberofTests * 100)
 $timecost.Text = "Running: $myvar1"

 }




I have a windows forms label that i want to update the value of the form label while it keeps running an exe. the write-progress command puts out to $myvar.
$Myvar outputs to the form lable timecost. 
I want to allow the form to stay open and function after this test is finished. but if the test does not finish in a period of time, can the keyboardhandler 
break the loop and allow the script to move on? 

ALso there is an output to $myvar only every 5 minutes or so. is this while loop the right way to handle this 