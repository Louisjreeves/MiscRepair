﻿# ... Your other code ...

# Create an instance of the keyboard handler and add it as a message filter
$keyboardHandler = New-Object -TypeName KeyboardHandler
[System.Windows.Forms.Application]::AddMessageFilter($keyboardHandler)

# Create the timecost label (moved outside the event handler)
$timecost = New-Object System.Windows.Forms.Label
$timecost.Location = New-Object System.Drawing.Size(330, 80)
$timecost.Size = New-Object System.Drawing.Size(500, 30)
$Font = New-Object System.Drawing.Font("Times New Roman", 14, [System.Drawing.FontStyle]::Bold)
$timecost.Font = $Font
$timecost.TransparencyKey = $backgroundImage.GetPixel(100, 500)
$timecost.BackColor = $backgroundImage.GetPixel(100, 400)
$Form.Controls.Add($timecost)

# Set $myvar1 to $null initially
$myvar1 = $null

while ($myvar1) {
    $myvar1 = Write-Progress -Activity ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat" -status "Test in progress" -percentComplete ($counter / $NumberofTests * 100)
    $timecost.Text = "Running: $myvar1"

    # Wait for 5 minutes before the next update
    Start-Sleep -Seconds (5 * 60)
}

# Remove the keyboard handler before exiting
[System.Windows.Forms.Application]::RemoveMessageFilter($keyboardHandler)

# Allow the form to remain open and functional after the loop finishes
$Form.ShowDialog()
