﻿ 

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
Set-Location  "$mydownloads\CornersTestandGraph\"
 

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$ErrorActionPreference = 'SilentlyContinue'
 $WarningPreference = 'SilentlyContinue'

# Adjust the size of the PictureBox control based on the form size
function ResizePictureBox() {
    $pictureBoxImage.Width = $form.ClientSize.Width * 1.0
    $pictureBoxImage.Height = $form.ClientSize.Height * 1.0
    $pictureBoxImage.Left = ($form.ClientSize.Width - $pictureBoxImage.Width) / 2
    $pictureBoxImage.Top = ($form.ClientSize.Height - $pictureBoxImage.Height) / 2
}

Function Graphall {

Param (

[string]$Global:disk 


)

 
{write-host "i am groot!!"}

}   

function randomIOPS
{write-host "i do the same as graphall!"}
 

function SeqThrouPut
{

Param (

[string]$Global:disk 


)
write-host "i do the same as graphall!"

}

 

function mini1
{

 
Param (

[string]$Global:disk 


)

# Drive performance Report Generator
# by Arnaud TORRES
# Microsoft provides script, macro, and other code examples for illustration only, without warranty either expressed or implied, including but not
# limited to the implied warranties of merchantability and/or fitness for a particular purpose. This script is provided 'as is' and Microsoft does not
# guarantee that the following script, macro, or code can be used in all situations.
# Script will stress your computer CPU and storage, be sure that no critical workload is running

# Clear screen
Clear
Write-host "Disk status $global:disk"
write-host "DRIVE PERFORMANCE REPORT GENERATOR" -foregroundcolor green
write-host "Script will stress your computer CPU and storage layer (including network if applciable !), be sure that no critical workload is running" -foregroundcolor yellow
write-host "Microsoft provides script, macro, and other code examples for illustration only, without warranty either expressed or implied, including but not limited to the implied warranties of merchantability and/or fitness for a particular purpose. This script is provided 'as is' and Microsoft does not guarantee that the following script, macro, or code can be used in all situations." -foregroundcolor yellow
"   "
Write-host "Disk status $global:disk"

"Test will use all free space on drive minus 2 GB !"
"If there are less than 4 GB free test will stop"

# Disk to test
#$$global:disk = Read-Host 'Which disk would you like to test ? (example : D:)'

# $Disk = "D:"
Write-host "Disk status $global:disk"
if ($global:disk.length -ne 2){"Wrong drive letter format used, please specify the drive as D:"
return}
Write-host "Disk status $global:disk"
if ($global:disk.substring(1,1) -ne ":"){"Wrong drive letter format used, please specify the drive as D:"
return}
Write-host "Disk status $global:disk"
$global:disk = $global:disk.ToUpper()

# Reset test counter
$counter = 0

# Use 1 thread / core
$Thread = "-t"+(Get-WmiObject win32_processor).NumberofCores

# Set time in seconds for each run
# 10-120s is fine
$Time = "-d30"

# Outstanding IOs
# Should be 2 times the number of disks in the RAID
# Between  8 and 16 is generally fine
$OutstandingIO = "-o16"

# Disk preparation
# Delete testfile.dat if it exists
# The test will use all free space -2GB

$IsDir = test-path -path "$global:disk\TestDiskSpd"
$isdir
if ($IsDir -like "False"){new-item -itemtype directory -path "$global:disk\TestDiskSpd\"}

# Just a little security, in case we are working on a compressed drive ...
compact /u /s $global:disk\TestDiskSpd\

$Cleaning = test-path -path "$global:disk\TestDiskSpd\testfile.dat"
if ($Cleaning -eq "True")
{"Removing current testfile.dat from drive"
remove-item $global:disk\TestDiskSpd\testfile.dat}

$Disks = Get-WmiObject win32_logicaldisk
$LogicalDisk = $Disks | where {$_.DeviceID -eq $global:disk}
$Freespace = $LogicalDisk.freespace
$FreespaceGB = [int]($Freespace / 1073741824)
if($FreespaceGB -gt 6){
$Capacity = 6
}
Else{
Write-host "Not enought free space ($freespaceGB), need at least 6GB"
return}
$CapacityParameter = "-c"+$Capacity+"G"
$CapacityO = $Capacity * 1073741824
if ($FreespaceGB -lt "4"){
"Not enough space on the Disk ! More than 4GB needed"
return}

Write-host " "
$Continue = Read-Host "You are about to test $global:disk which has $FreespaceGB GB free, do you wan't to continue ? (Y/N) "
if ($continue -ne "y" -or $continue -ne "Y"){"Test Cancelled !!"
return}

 
 
write-host "Initialization can take some time, we are generating a $Capacity GB file..."

 
# Initialize outpout file
$date = get-date

# Add the tested disk and the date in the output file
"Disque $global:disk, $date" >> ./output.txt

# Add the headers to the output file
“Test N#, Drive, Operation, Access, Blocks, Run N#, IOPS, MB/sec, Latency ms, CPU %" >> ./output.txt

# Number of tests
# Multiply the number of loops to change this value
# By default there are : (4 blocks sizes) X (2 for read 100% and write 100%) X (2 for Sequential and Random) X (4 Runs of each)
#choosing 1 block size X 2 (read and write) x2 (seq and random)
$NumberOfTests = 2


write-host "TEST RESULTS (also logged in .\output.txt)" -foregroundcolor yellow

# Begin Tests loops
# We will run the tests with 4K, 8K, 64K and 512K blocks

(4,8) | % { 
$BlockParameter = ("-b"+$_+"K")
$Blocks = ("Blocks "+$_+"K")

# We will do Read tests and Write tests

(0,100) | % {
if ($_ -eq 0){$IO = "Read"}
if ($_ -eq 100){$IO = "Write"}
$WriteParameter = "-w"+$_

# We will do random and sequential IO tests
("r","si") | % {
if ($_ -eq "r"){$type = "Random"}
if ($_ -eq "si"){$type = "Sequential"}
$AccessParameter = "-"+$_

# Each run will be done 4 times
(1..2) | % {
# The test itself (finally !!)
$result = .\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat

# Now we will break the very verbose output of DiskSpd in a single line with the most important values
foreach ($line in $result) {if ($line -like "total:*") { $total=$line; break } }
foreach ($line in $result) {if ($line -like "avg.*") { $avg=$line; break } }
$mbps = $total.Split("|")[2].Trim()
$iops = $total.Split("|")[3].Trim()
$latency = $total.Split("|")[4].Trim()
$cpu = $avg.Split("|")[1].Trim()
$counter = $counter + 1

# A progress bar, for the fun
Write-Progress -Activity ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat" -status "Test in progress" -percentComplete ($counter / $NumberofTests * 100)

# Remove comment to check command line ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread -$OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat"
# We output the values to the text file
“Test $Counter,$global:disk,$IO,$type,$Blocks,Run $_,$iops,$mbps,$latency,$cpu"  >> ./output.txt

# We output a verbose format on screen
“Test $Counter, $global:disk, $IO, $type, $Blocks, Run $_, $iops iops, $mbps MB/sec, $latency ms, $cpu CPU"}}}}

#rename Output.txt to output.csv

# Check if data.csv already exists
$destinationPath = Join-Path $mydownloads "data.csv"
if (Test-Path $destinationPath) {
    # Append a unique number to the filename to avoid overwriting
    $count = 1
    while (Test-Path $destinationPath) {
        $destinationPath = Join-Path $mydownloads "data_$count.csv"
        $count++
    }
}

# Rename output.txt to data.csv
$sourcePath = Join-Path $mydownloads "output.txt"
Move-Item -Path $sourcePath -Destination $destinationPath

Set-location -Path $PSScriptRoot
# Check if data.csv already exists
$destinationPath = Join-Path $mydownloads "data.csv"
if (Test-Path $destinationPath) {
    # Append a unique number to the filename to avoid overwriting
    $count = 1
    while (Test-Path $destinationPath) {
        $destinationPath = Join-Path $mydownloads "data_$count.csv"
        $count++
    }
}

# Rename output.txt to data.csv
$sourcePath = Join-Path $mydownloads "output.txt"
Move-Item -Path $sourcePath -Destination $destinationPath


}



#53 minutes##
 function corner1
 {

 Param (

[string]$Global:disk 


)

 Write-host "Status of $global:disk is disk $global:disk"
 
 
 }

#morethen 40 min 
Function actualcorner {
Param (

[string]$Global:disk 


)

 Write-host "Status of $global:disk is disk $global:disk"

}



$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot

clear-host
Write-host "Welcome to 4 corners storage test baseline"

 
Set-Location  "$mydownloads\CornersTestandGraph\"

Rename-Item -Path "diskspd.__e" -NewName "diskspd.exe"
#Rename-Item -Path "DskSpd4C.ps1.renameme" -NewName "DskSpd4C.ps1"

$global:disk = read-host = "If your ready and you have a specific hard drive in mind, type it now with a colon: Ex. D:"

Write-host " Spinning up Test engine.. Please wait.. "
Sleep (4)

###Below is form action 
######################################################################################################################


#corner1 $global:disk
 

#region Main Form

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
set-loc $myscriptloc

$menuArray = "4Corner", "Long Full" ,"micro single"

    
$tracearray = "Graphall", "randomIOPS", "SeqThroughPut"
$performarray = "randomIOPS","SeqThroughPut"
$SupportArray = "randomIOPS","SeqThroughPut"
$Form = New-Object System.Windows.Forms.Form
$Form.Width = 782
$Form.Height = 303
$Form.Text = ".\cornerstestandgraph.ps1"


#Oryx_Antelope
$Image = [system.drawing.image]::FromFile("$($PSScriptRoot)\r.jpg")
$backgroundImage = $Image
$form.width = 1200
$form.height = 400
$form.Text = ”.\cornerstestandgraph.ps1”
## DROPDOWN TO CHOOSE COURSE OF COMMANDS 
$form.AutoSize = $false
$form.BackgroundImage = $Image
$form.BackgroundImageLayout = "None"
 # None, Tile, Center, Stretch, Zoom
$form.Width = $Image.Width
$form.Height = $Image.Height
$Font = New-Object System.Drawing.Font("Times New Roman",11,[System.Drawing.FontStyle]::Regular)
 # Font styles are: Regular, Bold, Italic, Underline, Strikeout
$form.TransparencyKey = $backgroundImage.GetPixel(100, 100)
$form.Font = $Font

# Create the first dropdown
$DropDown1 = New-Object System.Windows.Forms.ComboBox
$DropDown1.Location = New-Object System.Drawing.Size(150, 39)
$DropDown1.Size = New-Object System.Drawing.Size(133, 19)
$Dropown1.TransparencyKey = $backgroundImage.GetPixel(82, 29)
$DropDown1.BackColor = $backgroundImage.GetPixel(92,39)

# Create the second dropdown
$secondDropDown = New-Object System.Windows.Forms.ComboBox
$secondDropDown.Location = New-Object System.Drawing.Size(150, 79)
$secondDropDown.Size = New-Object System.Drawing.Size(146, 19)
$secondDropDown.TransparencyKey = $backgroundImage.GetPixel(83, 89)
$secondDropDown.BackColor = $backgroundImage.GetPixel(83,89)

$DropDown1.Items.AddRange($menuArray)

# Create the timecost label (moved outside the event handler)
$timecost = New-Object System.Windows.Forms.Label
$timecost.Location = New-Object System.Drawing.Size(330, 80)
$timecost.Size = New-Object System.Drawing.Size(500, 30)
$Font = New-Object System.Drawing.Font("Times New Roman", 14, [System.Drawing.FontStyle]::Bold)
$timecost.Font = $Font
$timecost.TransparencyKey = $backgroundImage.GetPixel(100, 500)
$timecost.BackColor = $backgroundImage.GetPixel(100, 400)
$Form.Controls.Add($timecost)

# Add event handler to first dropdown
$DropDown1.Add_SelectedIndexChanged({
    $selectedValue = $DropDown1.SelectedItem.ToString()
     
    $secondDropDown.Items.Clear()

    switch ($selectedValue) {
        '4Corner' {
            $secondDropDown.Items.AddRange($tracearray)
            $gettime = "20"
            $timecost.Text = "Test runs for at least $gettime Minutes"
        }
        'Long Full' {
            $secondDropDown.Items.AddRange($performarray)
            $gettime = "55"
            $timecost.Text = "Test runs for at least $gettime Minutes"
        }
        'micro single' {
            $secondDropDown.Items.AddRange($SupportArray)
            $gettime = "255"
            $timecost.Text = "Test runs for at least $gettime Minutes"
        }
    }
    $secondDropDown.Enabled = $true




})

$Form.Controls.Add($DropDown1)
$Form.Controls.Add($secondDropDown)

$DropDownLabel = New-Object System.Windows.Forms.Label
$DropDownLabel.Location = New-Object System.Drawing.Size(1, 39)
$DropDownLabel.Size = New-Object System.Drawing.Size(115, 20)
$DropDownLabel.TransparencyKey = $backgroundImage.GetPixel(20,30)
$DropDownLabel.BackColor = $backgroundImage.GetPixel(20,30)
$DropDownLabel.Text = "Type Test"
$Form.Controls.Add($DropDownLabel)

$secondLabel = New-Object System.Windows.Forms.Label
$secondLabel.Location = New-Object System.Drawing.Size(1, 80)
$secondLabel.Size = New-Object System.Drawing.Size(150, 20) 

$SecondLabel.TransparencyKey = $backgroundImage.GetPixel(82, 89)
$SecondLabel.BackColor = $backgroundImage.GetPixel(82, 89)
$secondLabel.Text = "Type of Report"
$Form.Controls.Add($secondLabel)
 

$Button = New-Object System.Windows.Forms.Button
$Button.Location = New-Object System.Drawing.Size(310, 29)
$Button.Size = New-Object System.Drawing.Size(240, 29)
$Button.Text = "Start Test Disk $global:disk"



$Button.Add_Click({
    # Handle the button click event
     
    $disktest1 = $DropDown1.SelectedItem.ToString()
    $disktest2 = $secondDropDown.SelectedItem.ToString()
   
 
   
   switch ($disktest1) {
        '4Corner' {
             actualcorner($global:disk)
            
             
        }
        'Long Full' {
           corner1($global:disk)
           
        }
        'micro single' {
           mini1($global:disk)
           
        }
    }
    $secondDropDown.Enabled = $true

   



})
$Form.Controls.Add($Button)

# Import the requiYellow namespace for keyboard handling
Add-Type -TypeDefinition @'
    using System;
    using System.Windows.Forms;
    
    public class KeyboardHandler : IMessageFilter
    {
        private const int WM_KEYDOWN = 0x0100;
        private const int VK_ESCAPE = 0x1B;

        public bool PreFilterMessage(ref Message m)
        {
            if (m.Msg == WM_KEYDOWN && (int)m.WParam == VK_ESCAPE)
            {
                Application.return();
                return true;
            }
            return false;
        }
    }
'@

# Create an instance of the keyboard handler and add it as a message filter
$keyboardHandler = New-Object -TypeName KeyboardHandler
[System.Windows.Forms.Application]::AddMessageFilter($keyboardHandler)

$secondButton = New-Object System.Windows.Forms.Button
$secondButton.Location = New-Object System.Drawing.Size(600, 43)
#235 151
$secondButton.Size = New-Object System.Drawing.Size(160, 30)
$secondButton.Text = "Open Graph"
$secondButton.Add_Click({ 
 
      $disktest2 = $secondDropDown.SelectedItem.ToString()
    # Resize the PictureBox control to fit the form size
    ResizePictureBox
        
    $Checking = test-path -path "$mydownloads\CornersTestandGraph\$disktest2"
if ($Checking -eq "True")
 {
 # Display the image in the PictureBox control
    $imagePath = "$mydownloads\CornersTestandGraph\$disktest2.png"  # Replace this with the path to your .bmp image
    $image = [System.Drawing.Image]::FromFile($imagePath)
    $pictureBoxImage.Image = $image
    $timecost.Text = "Graph Displayed from PS root Script folder"
 
 } else {
 $timecost.Text = "Graph Viewable when tests done and graph.png generated"
 $variable = "$global:disk"
 & $disktest2 -Name $variable

 
 

 $timecost.text = "Running Graph processing"

    $imagePath = "$mydownloads\CornersTestandGraph\$disktest2.png"  # Replace this with the path to your .bmp image
    $image = [System.Drawing.Image]::FromFile($imagePath)
    $pictureBoxImage.Image = $image
    $timecost.Text = "Graph Displayed from PS root Script folder"
}
    
})

 

$Form.Controls.Add($secondButton)



$thirdButton = New-Object System.Windows.Forms.Button
$thirdButton.Location = New-Object System.Drawing.Size(600, 5)

$thirdButton.Size = New-Object System.Drawing.Size(160, 25)
$thirdButton.Text = "Terminate and return"
$thirdButton.Add_Click({ closeall })
$Form.Controls.Add($thirdButton)

 



$DropDownLabel2 = New-Object System.Windows.Forms.Label
$DropDownLabel2.Location = New-Object System.Drawing.Size(1, 10)
$DropDownLabel2.Size = New-Object System.Drawing.Size(125, 20)
$DropDownLabel2.TransparencyKey = $backgroundImage.GetPixel(10, 10)
$DropDownLabel2.BackColor = $backgroundImage.GetPixel(21,15)
$Font = New-Object System.Drawing.Font("Times NewRoman", 11, [System.Drawing.FontStyle]::Bold)
$DropDownLabel2.font = $font
$DropDownLabel2.Text = "DiskSpd Testing"
$Form.Controls.Add($DropDownLabel2)
#########################################

 
# Create the PictureBox control
$pictureBoxImage = New-Object System.Windows.Forms.PictureBox
$pictureBoxImage.Size = New-Object System.Drawing.Size($Form.Width - 100, $Form.Height * 0.75)  # Adjust the size as needed
$pictureBoxImage.SizeMode = 'Zoom'  # Set the PictureBoxSizeMode to 'Zoom' to fit the image within the control

# Calculate the location to center the PictureBox horizontally from the bottom
$centerX = ($Form.Width - $pictureBoxImage.Width) / 2
$pictureBoxImage.Location = New-Object System.Drawing.Point($centerX, $Form.Height * 0.25)

# Add the PictureBox control to the form
$Form.Controls.Add($pictureBoxImage)

 

 



$Form.Add_Shown({ $Form.Activate() })
[void] $Form.ShowDialog()

#endregion Main Form

$form.close()
$form.dispose()