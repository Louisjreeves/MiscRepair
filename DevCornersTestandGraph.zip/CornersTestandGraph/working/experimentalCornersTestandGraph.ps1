﻿ 

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
Set-Location  "$mydownloads\CornersTestandGraph\"
  $ErrorActionPreference = 'silentlycontinue'
 $WarningPreference = 'silentlycontinue'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$global:form = New-Object System.Windows.Forms.Form
$ErrorActionPreference = 'SilentlyContinue'
 $WarningPreference = 'SilentlyContinue'

# Adjust the size of the PictureBox control based on the form size
function ResizePictureBox() {
    $pictureBoxImage.Width = $form.ClientSize.Width * 1.0
    $pictureBoxImage.Height = $form.ClientSize.Height * 1.0
    $pictureBoxImage.Left = ($form.ClientSize.Width - $pictureBoxImage.Width) / 2
    $pictureBoxImage.Top = ($form.ClientSize.Height - $pictureBoxImage.Height) / 2
}

 
function graphall {


  param (
        [string]$text,
        [string]$global:disk
    )
# Set the number of tests
$NumberOfTests = 8  # 4 tests (random read, sequential read, random write, sequential write) x 2 runs each

# Filter the data for read and write data
$read_data = $data | Where-Object { $_.Operation -like "*Read*" }
$write_data = $data | Where-Object { $_.Operation -like "*Write*" }

# Split the data into two sets based on the Access column
$read_random_access_data = $read_data | Where-Object { $_.Access -like "*Random*" }
$read_sequential_access_data = $read_data | Where-Object { $_.Access -like "*Sequential*" }
$random_write_access_data = $write_data | Where-Object { $_.Access -like "Random" }
$sequential_write_access_data = $write_data | Where-Object { $_.Access -like "Sequential" }

# Combine the two sets of data and create a new property to identify the access type
$read_combined_ran = $read_random_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Read_combined_seq = $read_sequential_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec
$write_combined_ran = $random_write_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Write_combined_seq = $sequential_write_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

# Initialize the chart and data series
$chart = New-Object System.Windows.Forms.DataVisualization.Charting.Chart
$chart.Width = 800
$chart.Height = 600

$chartArea = New-Object System.Windows.Forms.DataVisualization.Charting.ChartArea
$chart.ChartAreas.Add($chartArea)

$legend = New-Object System.Windows.Forms.DataVisualization.Charting.Legend
$legend.Docking = "bottom"
$chart.Legends.Add($legend)

# Create data series for random read, sequential read, random write, and sequential write
$dataSeries1 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries1.Name = "Random Read"
$dataSeries1.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries1.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries1.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries1.BorderWidth = 2
$dataSeries1.Color = [System.Drawing.Color]::Blue

$dataSeries2 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries2.Name = "Sequential Read"
$dataSeries2.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries2.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries2.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries2.BorderWidth = 2
$dataSeries2.Color = [System.Drawing.Color]::Yellow

$dataSeries11 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries11.Name = "Random Write"
$dataSeries11.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries11.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries11.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries11.BorderWidth = 2
$dataSeries11.Color = [System.Drawing.Color]::Green

$dataSeries21 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries21.Name = "Sequential Write"
$dataSeries21.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries21.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries21.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries21.BorderWidth = 2
$dataSeries21.Color = [System.Drawing.Color]::Yellow

# Loop through the data and create data points for each test
for ($i = 0; $i -lt $NumberOfTests; $i++) {
    $blocks = $read_combined_ran[$i % 4].Blocks
    $iops = $read_combined_ran[$i % 4].IOPS
    $dataSeries1.Points.AddXY($blocks, $iops)

    $blocks = $Read_combined_seq[$i % 4]."Blocks"
    $mb_sec = $Read_combined_seq[$i % 4]."MB/sec"
    $dataSeries2.Points.AddXY($blocks, $mb_sec)

    $blocks = $write_combined_ran[$i % 4].Blocks
    $iops = $write_combined_ran[$i % 4].IOPS
    $dataSeries11.Points.AddXY($blocks, $iops)

    $blocks = $Write_combined_seq[$i % 4]."Blocks"
    $mb_sec = $Write_combined_seq[$i % 4]."MB/sec"
    $dataSeries21.Points.AddXY($blocks, $mb_sec)
}

# Add the data series to the chart
$chart.Series.Add($dataSeries1)
$chart.Series.Add($dataSeries2)
$chart.Series.Add($dataSeries11)
$chart.Series.Add($dataSeries21)

# Save the chart image and data in JSON format
$chart.SaveImage("$localpath\graph.png", [System.Drawing.Imaging.ImageFormat]::Png)
$read_combined_ran | ConvertTo-Json | Out-File "$localpath\data.json" -Append
$Read_combined_seq | ConvertTo-Json | Out-File "$localpath\data.json" -Append
$write_combined_ran | ConvertTo-Json | Out-File "$localpath\data.json" -Append
$Write_combined_seq | ConvertTo-Json | Out-File "$localpath\data.json" -Append

# Initialize and show the chart form
$chartForm = New-Object System.Windows.Forms.Form
$chartForm.SuspendLayout()
$chart.Dock = [System.Windows.Forms.DockStyle]::Fill
$chartForm.Controls.Add($chart)
$chartForm.ResumeLayout()
$chartForm.ShowDialog()



}

Function randomIOPS {


  param (
        [string]$text,
        [string]$global:disk
    )
# the format has to be just like below
# Test N#	 Drive	 Operation	 Access	 Blocks	 Run N#	 IOPS	 MB/sec	 Latency ms	 CPU %
# place the numbers in the csv as csv or space seperated values 

# set path asap 
$mypath = $MyInvocation.MyCommand.path
$localpath = split-path $mypath -Parent

Set-Location -Path $localpath

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
Set-Location  "$mydownloads\CornersTestandGraph\"

Clear-Host
Write-host "The CSV file needs to be in this folder. It also must be in the proper format like the dat.csv"
write-host "Failure to do those things will result in you getting nothing valuable from this forray" -BackgroundColor Green
$keypressed = "dat.csv"
$keybus = Read-host "enter the name of the file you want me to do your work for you on. Enter=dat.csv"

if ([bool] $keybus -eq $true) {$keypressed = $keybus} else {$keypressed = "dat.csv"}
 


Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Windows.Forms.DataVisualization
 
# Load the data from a CSV file
$data = Import-Csv -Path "$localpath\dat.csv"

# Filter the data to include only rows where the Operation column contains "Read"
$read_data = $data | Where-Object { $_.Operation -like "*Read*" }


# Split the data into two sets based on the Access column
$read_random_access_data = $read_data | Where-Object { $_.Access -like "*Random*" }
#$read_sequential_access_data = $read_data | Where-Object { $_.Access -like "*Sequential*" }

#########test random read and sequential read data 
$read_random_access_data | ft
#$read_sequential_access_data | ft

# Combine the two sets of data and create a new property to identify the access type
$read_combined_ran = $read_random_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
#$Read_combined_seq = $read_sequential_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

##### FILTER THE DATA FOR WRITE DATA 
# Filter the data to include only rows where the Operation column contains "Write"
 $write_data = $data | Where-Object { $_.Operation -like "*Write*" }

# Split the data into two sets based on the Access column
$random_write_access_data = $write_data | Where-Object { $_.Access -like "Random" }
#$sequential_write_access_data = $write_data | Where-Object { $_.Access -like "Sequential" }

# Combine the two sets of data and create a new property to identify the access type
$write_combined_ran = $random_write_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
#$Write_combined_seq = $sequential_write_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

#### test random and sequentual writes 
#$write_combined_ran | ft
#$Write_combined_seq | ft
$random_write_access_data | ft
#$sequential_write_access_data | ft


#### FINISH FILTER FOR WRITE DATA 


Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Windows.Forms.DataVisualization
# Create the graph
$chart = New-Object System.Windows.Forms.DataVisualization.Charting.Chart
$chart.Width = 800
$chart.Height = 600

$chartArea = New-Object System.Windows.Forms.DataVisualization.Charting.ChartArea
$chart.ChartAreas.Add($chartArea)

$legend = New-Object System.Windows.Forms.DataVisualization.Charting.Legend
$legend.Docking = "bottom"
$chart.Legends.Add($legend)

$dataSeries1 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries1.Name = "Random Read"
$dataSeries1.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries1.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries1.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries1.BorderWidth = 2
$dataSeries1.Color = [System.Drawing.Color]::Blue

 

$dataSeries11 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries11.Name = "Random Write"
$dataSeries11.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries11.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries11.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries11.BorderWidth = 2
$dataSeries11.Color = [System.Drawing.Color]::Green

 

foreach ($item in $read_combined_ran) {
    $blocks= $item."blocks"
    $access = $item.Access
    #$mb_sec = $item."MB/sec"
    $iops = $item.IOPS
    
    if ($access -eq "Random") {
        $dataSeries1.Points.AddXY($Blocks,$iops)
    } 
}
 
#foreach ($item in $Read_combined_seq) {
 #   $access = $item.Access
 #   $mb_sec = $item."MB/sec"
 #   $blocks = $item."Blocks"
   # $iops = $item.IOPS

  #  if ($access -like "Sequential") {
   #     $dataSeries2.Points.AddXY($blocks, $mb_sec)
   # }
        
   
#}
 
foreach ($item in $write_combined_ran) {
    $access = $item.Access
   # $mb_sec = $item."MB/sec"
    $iops = $item.IOPS
    $blocks = $item."Blocks"

    if ($access -eq "Random") {
        $dataSeries11.Points.AddXY($Blocks, $iops)
    }
        
   
}


#foreach ($item in $Write_combined_seq) {
 #   $access = $item.Access
 #   $mb_sec = $item."MB/sec"
   # $iops = $item.IOPS
 #  $blocks = $item."Blocks"
  #  if ($access -like "sequential") {
   #     $dataSeries21.Points.AddXY($Blocks, $mb_sec)
  # }
        
   
#}



$chart.Series.Add($dataSeries1)
 

$chart.Series.Add($dataSeries11)
 

$chart.SaveImage("$localpath\RandomIOgraph.png", [System.Drawing.Imaging.ImageFormat]::Png)
#$combined_data | ConvertTo-Json | Out-File "$localpath\dataRandomIOPS.json" -Append
$read_combined_ran | ConvertTo-Json | Out-File "$localpath\dataRandomIOPS.json" -Append
#$Read_combined_seq | ConvertTo-Json | Out-File "$localpath\data.json" -Append
$write_combined_ran | ConvertTo-Json | Out-File "$localpath\dataRandomIOPS.json" -Append
#$Write_combined_seq | ConvertTo-Json | Out-File "$localpath\data.json" -Append


## Rule For Sequential IO - THROUGHPUT Don’t worry about the IO- Only the throughput matters
### Rule	For Random IO- Only IOPS matters- don’t worry about throughput 

$chartForm = New-Object System.Windows.Forms.Form
$chartForm.SuspendLayout()
$chart.Dock = [System.Windows.Forms.DockStyle]::Fill
$chartForm.Controls.Add($chart)
$chartForm.ResumeLayout()

# Show the form
$chartForm.ShowDialog()


}

Function SeqThrouPut {

   param (
        [string]$text,
        [string]$global:disk
    )
# the format has to be just like below
# Test N#	 Drive	 Operation	 Access	 Blocks	 Run N#	 IOPS	 MB/sec	 Latency ms	 CPU %
# place the numbers in the csv as csv or space seperated values 

# set path asap 
$mypath = $MyInvocation.MyCommand.path
$localpath = split-path $mypath -Parent

Set-Location -Path $localpath

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
Set-Location  "$mydownloads\CornersTestandGraph\"


Clear-Host
Write-host "The CSV file needs to be in this folder. It also must be in the proper format like the dat.csv"
write-host "Failure to do those things will result in you getting nothing valuable from this forray" -BackgroundColor Green
$keypressed = "dat.csv"
$keybus = Read-host "enter the name of the file you want me to do your work for you on. Enter=dat.csv"

if ([bool] $keybus -eq $true) {$keypressed = $keybus} else {$keypressed = "dat.csv"}
 


Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Windows.Forms.DataVisualization
 
# Load the data from a CSV file
$data = Import-Csv -Path "$localpath\dat.csv"

# Filter the data to include only rows where the Operation column contains "Read"
$read_data = $data | Where-Object { $_.Operation -like "*Read*" }


# Split the data into two sets based on the Access column
#$read_random_access_data = $read_data | Where-Object { $_.Access -like "*Random*" }
$read_sequential_access_data = $read_data | Where-Object { $_.Access -like "*Sequential*" }

#########test random read and sequential read data 
$read_random_access_data | ft
$read_sequential_access_data | ft

# Combine the two sets of data and create a new property to identify the access type
#$read_combined_ran = $read_random_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Read_combined_seq = $read_sequential_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

##### FILTER THE DATA FOR WRITE DATA 
# Filter the data to include only rows where the Operation column contains "Write"
 $write_data = $data | Where-Object { $_.Operation -like "*Write*" }

# Split the data into two sets based on the Access column
#$random_write_access_data = $write_data | Where-Object { $_.Access -like "Random" }
$sequential_write_access_data = $write_data | Where-Object { $_.Access -like "Sequential" }

# Combine the two sets of data and create a new property to identify the access type
#$write_combined_ran = $random_write_access_data | Select-Object @{Name="Access";Expression={"Random"}},Blocks,IOPS
$Write_combined_seq = $sequential_write_access_data | Select-Object @{Name="Access";Expression={"Sequential"}},Blocks,MB/sec

#### test random and sequentual writes 
#$write_combined_ran | ft
#$Write_combined_seq | ft
#$random_write_access_data | ft
$sequential_write_access_data | ft


#### FINISH FILTER FOR WRITE DATA 


Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Windows.Forms.DataVisualization
# Create the graph
$chart = New-Object System.Windows.Forms.DataVisualization.Charting.Chart
$chart.Width = 800
$chart.Height = 600

$chartArea = New-Object System.Windows.Forms.DataVisualization.Charting.ChartArea
$chart.ChartAreas.Add($chartArea)

$legend = New-Object System.Windows.Forms.DataVisualization.Charting.Legend
$legend.Docking = "bottom"
$chart.Legends.Add($legend)

 

$dataSeries2 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries2.Name = "Sequential Read"
$dataSeries2.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries2.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries2.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries2.BorderWidth = 2
$dataSeries2.Color = [System.Drawing.Color]::Yellow

 
$dataSeries21 = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$dataSeries21.Name = "Sequential Write"
$dataSeries21.XValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::String
$dataSeries21.YValueType = [System.Windows.Forms.DataVisualization.Charting.ChartValueType]::Double
$dataSeries21.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
$dataSeries21.BorderWidth = 2
$dataSeries21.Color = [System.Drawing.Color]::yellow

#foreach ($item in $read_combined_ran) {
    #$blocks= $item."blocks"
    #$access = $item.Access
    #$mb_sec = $item."MB/sec"
    #$iops = $item.IOPS
    
   # if ($access -eq "Random") {
  #      $dataSeries1.Points.AddXY($Blocks,$iops)
 #   } 
#}
 
foreach ($item in $Read_combined_seq) {
    $access = $item.Access
    $mb_sec = $item."MB/sec"
    $blocks = $item."Blocks"
   # $iops = $item.IOPS

    if ($access -like "Sequential") {
        $dataSeries2.Points.AddXY($blocks, $mb_sec)
    }
        
   
}
 
#foreach ($item in $write_combined_ran) {
 #   $access = $item.Access
 #  # $mb_sec = $item."MB/sec"
 #   $iops = $item.IOPS
 #   $blocks = $item."Blocks"
#
#    if ($access -eq "Random") {
#        $dataSeries11.Points.AddXY($Blocks, $iops)
#    }
        
   
#}


foreach ($item in $Write_combined_seq) {
    $access = $item.Access
    $mb_sec = $item."MB/sec"
   # $iops = $item.IOPS
   $blocks = $item."Blocks"
    if ($access -like "sequential") {
        $dataSeries21.Points.AddXY($Blocks, $mb_sec)
    }
        
   
}



 
$chart.Series.Add($dataSeries2)

$chart.Series.Add($dataSeries21)

$chart.SaveImage("$localpath\graphSequential_Throughput.png", [System.Drawing.Imaging.ImageFormat]::Png)
#$combined_data | ConvertTo-Json | Out-File "$localpath\data.json" -Append
#$read_combined_ran | ConvertTo-Json | Out-File "$localpath\dataSEQ.json" -Append
$Read_combined_seq | ConvertTo-Json | Out-File "$localpath\dataSEQ_mbPERsec.json" -Append
#$write_combined_ran | ConvertTo-Json | Out-File "$localpath\dataSEQ.json" -Append
$Write_combined_seq | ConvertTo-Json | Out-File "dataSEQ_mbPERsec.json" -Append


## Rule For Sequential IO - THROUGHPUT Don’t worry about the IO- Only the throughput matters
### Rule	For Random IO- Only IOPS matters- don’t worry about throughput 

$chartForm = New-Object System.Windows.Forms.Form
$chartForm.SuspendLayout()
$chart.Dock = [System.Windows.Forms.DockStyle]::Fill
$chartForm.Controls.Add($chart)
$chartForm.ResumeLayout()

# Show the form
$chartForm.ShowDialog()




}

function mini1
{

 
Param (

[string]$Global:disk 


)

# Drive performance Report Generator
# by Arnaud TORRES
# Microsoft provides script, macro, and other code examples for illustration only, without warranty either expressed or implied, including but not
# limited to the implied warranties of merchantability and/or fitness for a particular purpose. This script is provided 'as is' and Microsoft does not
# guarantee that the following script, macro, or code can be used in all situations.
# Script will stress your computer CPU and storage, be sure that no critical workload is running

# Clear screen
Clear

Write-host "We are dealing with $globaldisk"

write-host "DRIVE PERFORMANCE REPORT GENERATOR" -foregroundcolor green
write-host "Script will stress your computer CPU and storage layer (including network if applciable !), be sure that no critical workload is running" -foregroundcolor yellow
write-host "Microsoft provides script, macro, and other code examples for illustration only, without warranty either expressed or implied, including but not limited to the implied warranties of merchantability and/or fitness for a particular purpose. This script is provided 'as is' and Microsoft does not guarantee that the following script, macro, or code can be used in all situations." -foregroundcolor yellow
"   "
"Test will use all free space on drive minus 2 GB !"
"If there are less than 4 GB free test will stop"

# Disk to test
#$$global:disk = Read-Host 'Which disk would you like to test ? (example : D:)'

# $Disk = "D:"
Write-host "Disk status $global:disk"
if ($global:disk.length -ne 2){"Wrong drive letter format used, please specify the drive as D:"
return}

if ($global:disk.substring(1,1) -ne ":"){"Wrong drive letter format used, please specify the drive as D:"
return}
Write-host "Disk status $global:disk"

$global:disk = $global:disk.ToUpper()

# Reset test counter
$counter = 0

# Use 1 thread / core
$Thread = "-t"+(Get-WmiObject win32_processor).NumberofCores

# Set time in seconds for each run
# 10-120s is fine
$Time = "-d30"

# Outstanding IOs
# Should be 2 times the number of disks in the RAID
# Between  8 and 16 is generally fine
$OutstandingIO = "-o16"

# Disk preparation
# Delete testfile.dat if it exists
# The test will use all free space -2GB

$IsDir = test-path -path "$global:disk\TestDiskSpd"
$isdir
if ($IsDir -like "False"){new-item -itemtype directory -path "$global:disk\TestDiskSpd\"}

# Just a little security, in case we are working on a compressed drive ...
compact /u /s $global:disk\TestDiskSpd\

$Cleaning = test-path -path "$global:disk\TestDiskSpd\testfile.dat"
if ($Cleaning -eq "True")
{"Removing current testfile.dat from drive"
remove-item $global:disk\TestDiskSpd\testfile.dat}

$Disks = Get-WmiObject win32_logicaldisk
$LogicalDisk = $Disks | where {$_.DeviceID -eq $global:disk}
$Freespace = $LogicalDisk.freespace
$FreespaceGB = [int]($Freespace / 1073741824)
if($FreespaceGB -gt 6){
$Capacity = 6
}
Else{
Write-host "Not enought free space ($freespaceGB), need at least 6GB"
return}
$CapacityParameter = "-c"+$Capacity+"G"
$CapacityO = $Capacity * 1073741824
if ($FreespaceGB -lt "4"){
"Not enough space on the Disk ! More than 4GB needed"
return}

Write-host " "
$Continue = Read-Host "You are about to test $global:disk which has $FreespaceGB GB free, do you wan't to continue ? (Y/N) "
if ($continue -ne "y" -or $continue -ne "Y"){"Test Cancelled !!"
return}



"Initialization can take some time, we are generating a $Capacity GB file..."


# Initialize outpout file
$date = get-date

# Add the tested disk and the date in the output file
"Disque $global:disk, $date" >> ./output.txt

# Add the headers to the output file
“Test N#, Drive, Operation, Access, Blocks, Run N#, IOPS, MB/sec, Latency ms, CPU %" >> ./output.txt

# Number of tests
# Multiply the number of loops to change this value
# By default there are : (4 blocks sizes) X (2 for read 100% and write 100%) X (2 for Sequential and Random) X (4 Runs of each)
#choosing 1 block size X 2 (read and write) x2 (seq and random)
$NumberOfTests = 4


write-host "TEST RESULTS (also logged in .\output.txt)" -foregroundcolor yellow

# Begin Tests loops
# We will run the tests with 4K, 8K, 64K and 512K blocks

(8) | % { 
$BlockParameter = ("-b"+$_+"K")
$Blocks = ("Blocks "+$_+"K")

# We will do Read tests and Write tests

(0,100) | % {
if ($_ -eq 0){$IO = "Read"}
if ($_ -eq 100){$IO = "Write"}
$WriteParameter = "-w"+$_

# We will do random and sequential IO tests
("r","si") | % {
if ($_ -eq "r"){$type = "Random"}
if ($_ -eq "si"){$type = "Sequential"}
$AccessParameter = "-"+$_

# Each run will be done 4 times
(1..1) | % {
# The test itself (finally !!)
$result = .\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat

# Now we will break the very verbose output of DiskSpd in a single line with the most important values
foreach ($line in $result) {if ($line -like "total:*") { $total=$line; break } }
foreach ($line in $result) {if ($line -like "avg.*") { $avg=$line; break } }
$mbps = $total.Split("|")[2].Trim()
$iops = $total.Split("|")[3].Trim()
$latency = $total.Split("|")[4].Trim()
$cpu = $avg.Split("|")[1].Trim()
$counter = $counter + 1

# A progress bar, for the fun
Write-Progress -Activity ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat" -status "Test in progress" -percentComplete ($counter / $NumberofTests * 100)

# Remove comment to check command line ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread -$OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat"
# We output the values to the text file
“Test $Counter,$global:disk,$IO,$type,$Blocks,Run $_,$iops,$mbps,$latency,$cpu"  >> ./output.txt

# We output a verbose format on screen
“Test $Counter, $global:disk, $IO, $type, $Blocks, Run $_, $iops iops, $mbps MB/sec, $latency ms, $cpu CPU"}}}}

#rename Output.txt to output.csv

# Check if data.csv already exists
$destinationPath = Join-Path $mydownloads "data.csv"
if (Test-Path $destinationPath) {
    # Append a unique number to the filename to avoid overwriting
    $count = 1
    while (Test-Path $destinationPath) {
        $destinationPath = Join-Path $mydownloads "data_$count.csv"
        $count++
    }
}

# Rename output.txt to data.csv
$sourcePath = Join-Path $mydownloads "output.txt"
Move-Item -Path $sourcePath -Destination $destinationPath

Set-location -Path $PSScriptRoot
# Check if data.csv already exists
$destinationPath = Join-Path $mydownloads "data.csv"
if (Test-Path $destinationPath) {
    # Append a unique number to the filename to avoid overwriting
    $count = 1
    while (Test-Path $destinationPath) {
        $destinationPath = Join-Path $mydownloads "data_$count.csv"
        $count++
    }
}

# Rename output.txt to data.csv
$sourcePath = Join-Path $mydownloads "output.txt"
Move-Item -Path $sourcePath -Destination $destinationPath


}

Function Singletest
{

  param (
        [string]$text,
        [string]$global:disk
    )

# Drive performance Report Generator
# Original by Arnaud TORRES, Edited by Hans Lenze Kaper on 25 - sep - 2015
$ErrorActionPreference = 'silentlycontinue'
$WarningPreference = 'silentlycontinue'
# Clear screen
Clear-host

write-host "DRIVE PERFORMANCE REPORT GENERATOR" -foregroundcolor green
write-host "Script will stress your computer CPU and storage layer (including network if applicable!), be sure that no critical workload is running" -foregroundcolor yellow

# Disk to test
$Disk = Read-Host 'Which path would you like to test? (example - C:\ClusterStorage\Volume1 or \\fileserver\share or S:) Without the trailing \'

# Set time in seconds for each run
# 10-120s is fine
$TimeInput = Read-Host 'Duration: How long should each run take in seconds? (example - 60)'
$Time = "-d" + $TimeInput

# Choose how big the benchmark file should be. Make sure it is at least two times the size of the available cache.
$capacity = Read-Host 'Testfile size: How big should the benchmark file be in GigaBytes? At least two times the cache size (example - 100)'
$CapacityParameter = "-c" + $Capacity + "G"

# Get date for the output file
$date = get-date

# Add the tested disk and the date in the output file
"Command used for the runs .\diskspd.exe -c[testfileSize]G -d[duration] -[randomOrSequential] -w[%write] -t[NumberOfThreads] -o[queue] -b[blocksize] -h -L $Disk\DiskStress\testfile.dat, $date" >> ./output.txt

# Add the headers to the output file
"Test N#, Drive, Operation, Access, Blocks, QueueDepth, Run N#, IOPS, MB/sec, Latency ms, CPU %" >> ./output.txt

write-host "TEST RESULTS (also logged in .\output.txt)" -foregroundcolor yellow

# Begin Tests loops
$NumberOfTests = 16  # 4 tests (read random, read sequential, write random, write sequential) x 4 runs each

$QueueDepths = 1, 8, 16, 32
$BlockSizes = 4, 4, 4, 4   # 4k block size for all tests
$ReadWrite = 0, 0, 100, 100  # 0 for read, 100 for write
$RandomSequential = "r", "si", "r", "si"

for ($i = 0; $i -lt $NumberOfTests; $i++) {
    $QueueDepth = $QueueDepths[$i % 4]
    $BlockSize = $BlockSizes[$i % 4]
    $ReadWriteValue = $ReadWrite[$i % 4]
    $RandomSequentialValue = $RandomSequential[$i % 4]

    if ($ReadWriteValue -eq 0) { $IO = "Read" }
    else { $IO = "Write" }

    if ($RandomSequentialValue -eq "r") { $type = "Random" }
    else { $type = "Sequential" }

    $queueparameter = ("-o" + $QueueDepth)
    $queue = ("QueueDepth " + $QueueDepth)

    $BlockParameter = "-b" + $BlockSize + "K"
    $Blocks = ("Blocks " + $BlockSize + "K")

    $WriteParameter = "-w" + $ReadWriteValue
    $AccessParameter = "-" + $RandomSequentialValue

    # Each run will be done 4 times for consistency
    for ($run = 1; $run -le 4; $run++) {

        # The test itself (finally !!)
        $result = .\diskspd.exe $CapacityParameter $Time $AccessParameter $WriteParameter "-t1" $queueparameter $BlockParameter -h -L "$Disk\TestDiskSpd\testfile.dat"

        # Now we will break the very verbose output of DiskSpd in a single line with the most important values
        foreach ($line in $result) {
            if ($line -like "total:*") { $total = $line; break }
        }
        foreach ($line in $result) {
            if ($line -like "avg.*") { $avg = $line; break }
        }
        $mbps = $total.Split("|")[2].Trim()
        $iops = $total.Split("|")[3].Trim()
        $latency = $total.Split("|")[4].Trim()
        $cpu = $avg.Split("|")[1].Trim()

        $counter++

        # A progress bar, for fun
        Write-Progress -Activity ".\diskspd.exe $CapacityParameter $Time $AccessParameter $WriteParameter -t1 $queueparameter $BlockParameter -h -L $Disk\TestDiskSpd\testfile.dat" -status "Test in progress" -percentComplete ($counter / $NumberOfTests * 100)

        # We output the values to the text file
        "Test $Counter,$Disk,$IO,$type,$Blocks,$queue,Run $run,$iops,$mbps,$latency,$cpu" >> ./output.txt

        # We output a verbose format on screen
        "Test $Counter, $Disk, $IO, $type, $Blocks, $queue, Run $run, $iops iops, $mbps MB/sec, $latency ms, $cpu CPU"
    }
}


}


#53 minutes##
Function corner1
{
  param (
        [string]$text,
        [string]$global:disk
    )
 $ErrorActionPreference = 'silentlycontinue'
 $WarningPreference = 'silentlycontinue'
# Drive performance Report Generator
# by Arnaud TORRES
# Microsoft provides script, macro, and other code examples for illustration only, without warranty either expressed or implied, including but not
# limited to the implied warranties of merchantability and/or fitness for a particular purpose. This script is provided 'as is' and Microsoft does not
# guarantee that the following script, macro, or code can be used in all situations.
# Script will stress your computer CPU and storage, be sure that no critical workload is running

# Clear screen
Clear

write-host "DRIVE PERFORMANCE REPORT GENERATOR" -foregroundcolor green
write-host "Script will stress your computer CPU and storage layer (including network if applciable !), be sure that no critical workload is running" -foregroundcolor yellow
write-host "Microsoft provides script, macro, and other code examples for illustration only, without warranty either expressed or implied, including but not limited to the implied warranties of merchantability and/or fitness for a particular purpose. This script is provided 'as is' and Microsoft does not guarantee that the following script, macro, or code can be used in all situations." -foregroundcolor yellow
"   "
"Test will use all free space on drive minus 2 GB !"
"If there are less than 4 GB free test will stop"

# Disk to test
#$$global:disk = Read-Host 'Which disk would you like to test ? (example : D:)'

# $Disk = "D:"

if ($global:disk.length -ne 2){"Wrong drive letter format used, please specify the drive as D:"
return}

if ($global:disk.substring(1,1) -ne ":"){"Wrong drive letter format used, please specify the drive as D:"
return}

$global:disk = $global:disk.ToUpper()

# Reset test counter
$counter = 0

# Use 1 thread / core
$Thread = "-t"+(Get-WmiObject win32_processor).NumberofCores

# Set time in seconds for each run
# 10-120s is fine
$Time = "-d30"

# Outstanding IOs
# Should be 2 times the number of disks in the RAID
# Between  8 and 16 is generally fine
$OutstandingIO = "-o16"

# Disk preparation
# Delete testfile.dat if it exists
# The test will use all free space -2GB

$IsDir = test-path -path "$global:disk\TestDiskSpd"
$isdir
if ($IsDir -like "False"){new-item -itemtype directory -path "$global:disk\TestDiskSpd\"}

# Just a little security, in case we are working on a compressed drive ...
compact /u /s $global:disk\TestDiskSpd\

$Cleaning = test-path -path "$global:disk\TestDiskSpd\testfile.dat"
if ($Cleaning -eq "True")
{"Removing current testfile.dat from drive"
remove-item $global:disk\TestDiskSpd\testfile.dat}

$Disks = Get-WmiObject win32_logicaldisk
$LogicalDisk = $Disks | where {$_.DeviceID -eq $global:disk}
$Freespace = $LogicalDisk.freespace
$FreespaceGB = [int]($Freespace / 1073741824)
if($FreespaceGB -gt 6){
$Capacity = 6
}
Else{
Write-host "Not enought free space ($freespaceGB), need at least 6GB"
return}
$CapacityParameter = "-c"+$Capacity+"G"
$CapacityO = $Capacity * 1073741824
if ($FreespaceGB -lt "4"){
"Not enough space on the Disk ! More than 4GB needed"
return}

Write-host " "
$Continue = Read-Host "You are about to test $global:disk which has $FreespaceGB GB free, do you wan't to continue ? (Y/N) "
if ($continue -ne "y" -or $continue -ne "Y"){"Test Cancelled !!"
return}



"Initialization can take some time, we are generating a $Capacity GB file..."


# Initialize outpout file
$date = get-date

# Add the tested disk and the date in the output file
"Disque $global:disk, $date" >> ./output.txt

# Add the headers to the output file
“Test N#, Drive, Operation, Access, Blocks, Run N#, IOPS, MB/sec, Latency ms, CPU %" >> ./output.txt

# Number of tests
# Multiply the number of loops to change this value
# By default there are : (4 blocks sizes) X (2 for read 100% and write 100%) X (2 for Sequential and Random) X (4 Runs of each)

$NumberOfTests = 64


write-host "TEST RESULTS (also logged in .\output.txt)" -foregroundcolor yellow

# Begin Tests loops
# We will run the tests with 4K, 8K, 64K and 512K blocks

# Begin Tests loops
# We will run the tests with 4K, 8K, 64K, and 512K blocks
(4, 8, 64, 512) | ForEach-Object { 
    $BlockParameter = "-b$_`K"
    $Blocks = "Blocks $_`K"

    # We will do Read tests and Write tests
    (0, 100) | ForEach-Object {
        if ($_ -eq 0) { $IO = "Read" }
        if ($_ -eq 100) { $IO = "Write" }
        $WriteParameter = "-w$_"

        # We will do random and sequential IO tests
        ("r", "si") | ForEach-Object {
            if ($_ -eq "r") { $type = "Random" }
            if ($_ -eq "si") { $type = "Sequential" }
            $AccessParameter = "-$_"

            # Each run will be done 4 times
            (1..4) | ForEach-Object {
                # The test itself (finally !!)
                $result = .\diskspd.exe $CapacityParameter $Time $AccessParameter $WriteParameter $Thread $OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat

                # Rest of the code remains unchanged
                # ...
                # ...
                # ...

                # Remove comment to check command line ".\diskspd.exe $CapacityParameter $Time $AccessParameter $WriteParameter $Thread -$OutstandingIO $BlockParameter -h -L $global:disk\TestDiskSpd\testfile.dat"
                # We output the values to the text file
                “Test $Counter,$global:disk,$IO,$type,$Blocks,Run $_,$iops,$mbps,$latency,$cpu"  >> ./output.txt

                # We output a verbose format on the screen
                “Test $Counter, $global:disk, $IO, $type, $Blocks, Run $_, $iops iops, $mbps MB/sec, $latency ms, $cpu CPU"
                
                # Increment the counter and check if we reached the desired number of tests
                $counter++
                if ($counter -ge $NumberOfTests) {
                    Write-Host "Test completed after $NumberOfTests tests."
                    return
                }
            }
        }
    }
}


#rename Output.txt to output.csv

# Check if data.csv already exists
$destinationPath = Join-Path $mydownloads "data.csv"
if (Test-Path $destinationPath) {
    # Append a unique number to the filename to avoid overwriting
    $count = 1
    while (Test-Path $destinationPath) {
        $destinationPath = Join-Path $mydownloads "data_$count.csv"
        $count++
    }
}

# Rename output.txt to data.csv
$sourcePath = Join-Path $mydownloads "output.txt"
Move-Item -Path $sourcePath -Destination $destinationPath

Set-location -Path $PSScriptRoot
# Check if data.csv already exists
$destinationPath = Join-Path $mydownloads "data.csv"
if (Test-Path $destinationPath) {
    # Append a unique number to the filename to avoid overwriting
    $count = 1
    while (Test-Path $destinationPath) {
        $destinationPath = Join-Path $mydownloads "data_$count.csv"
        $count++
    }
}

# Rename output.txt to data.csv
$sourcePath = Join-Path $mydownloads "output.txt"
Move-Item -Path $sourcePath -Destination $destinationPath


}

#morethen 40 min 
 #morethen 40 min 
Function actualcorner {

  param (
        [string]$text,
        [string]$global:disk
    )

# Drive performance Report Generator
# by Arnaud TORRES
# Microsoft provides script, macro, and other code examples for illustration only, without warranty either expressed or implied, including but not
# limited to the implied warranties of merchantability and/or fitness for a particular purpose. This script is provided 'as is' and Microsoft does not
# guarantee that the following script, macro, or code can be used in all situations.
# Script will stress your computer CPU and storage, be sure that no critical workload is running

# Clear screen
Clear

write-host "DRIVE PERFORMANCE REPORT GENERATOR" -foregroundcolor green
write-host "Script will stress your computer CPU and storage layer (including network if applciable !), be sure that no critical workload is running" -foregroundcolor yellow
write-host "Microsoft provides script, macro, and other code examples for illustration only, without warranty either expressed or implied, including but not limited to the implied warranties of merchantability and/or fitness for a particular purpose. This script is provided 'as is' and Microsoft does not guarantee that the following script, macro, or code can be used in all situations." -foregroundcolor Yellow
"   "
"Test will use all free space on drive minus 2 GB !"
"If there are less than 4 GB free test will stop"
$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
Set-Location  "$mydownloads\CornersTestandGraph\"


# Disk to test
#$Disk = Read-Host 'Which disk would you like to test ? (example : D:)'
$disk = $global:disk
# $Disk = "D:"

if ($disk.length -ne 2){"Wrong drive letter format used, please specify the drive as D:"
return}

if ($disk.substring(1,1) -ne ":"){"Wrong drive letter format used, please specify the drive as D:"
return}

$disk = $disk.ToUpper()

# Reset test counter
$counter = 0

# Use 1 thread / core
$Thread = "-t"+(Get-WmiObject win32_processor).NumberofCores

# Set time in seconds for each run
# 10-120s is fine
$Time = "-d60"

# Outstanding IOs
# Should be 2 times the number of disks in the RAID
# Between  8 and 16 is generally fine
$OutstandingIO = "-o16"

# Disk preparation
# Delete testfile.dat if it exists
# The test will use all free space -2GB

$IsDir = test-path -path "$Disk\TestDiskSpd"
$isdir
if ($IsDir -like "False"){new-item -itemtype directory -path "$Disk\TestDiskSpd\"}

# Just a little security, in case we are working on a compressed drive ...
compact /u /s $Disk\TestDiskSpd\

$Cleaning = test-path -path "$Disk\TestDiskSpd\testfile.dat"
if ($Cleaning -eq "True")
{"Removing current testfile.dat from drive"
remove-item $Disk\TestDiskSpd\testfile.dat}

$Disks = Get-WmiObject win32_logicaldisk
$LogicalDisk = $Disks | where {$_.DeviceID -eq $Disk}
$Freespace = $LogicalDisk.freespace
$FreespaceGB = [int]($Freespace / 1073741824)
if($FreespaceGB -gt 6){
$Capacity = 12
}
Else{
Write-host "Not enought free space ($freespaceGB), need at least 6GB"
return}
$CapacityParameter = "-c"+$Capacity+"G"
$CapacityO = $Capacity * 1073741824
if ($FreespaceGB -lt "4"){
"Not enough space on the Disk ! More than 4GB needed"
return}

Write-host " "
$Continue = Read-Host "You are about to test $Disk which has $FreespaceGB GB free, do you wan't to continue ? (Y/N) "
if ($continue -ne "y" -or $continue -ne "Y"){"Test Cancelled !!"
return}



"Initialization can take some time, we are generating a $Capacity GB file..."


# Initialize outpout file
$date = get-date

# Add the tested disk and the date in the output file
$servicetag= (get-wmiobject win32_systemEnclosure).SerialNumber
$dinfo = (get-volume).Size

"Disk $disk, $date, $servicetag, $dinfo" >> ./output.txt

# Add the headers to the output file
“Test N#, Drive, Operation, Access, Blocks, Run N#, IOPS, MB/sec, Latency ms, CPU %" >> ./output.txt

# Number of tests
# Multiply the number of loops to change this value
# By default there are : (4 blocks sizes) X (2 for read 100% and write 100%) X (2 for Sequential and Random) X (4 Runs of each)

$NumberOfTests = 16


write-host "TEST RESULTS (also logged in .\output.txt)" -foregroundcolor yellow

# Begin Tests loops
# We will run the tests with 4K, 8K, 64K and 512K blocks

 (4, 8, 64, 512) | ForEach-Object {
    # Rest of the code remains unchanged
    # ...
    # ...

    # We will do Read tests and Write tests
    (0, 100) | ForEach-Object {
        # Rest of the code remains unchanged
        # ...
        # ...

        # We will do random and sequential IO tests
        ("r", "si") | ForEach-Object {
            # Rest of the code remains unchanged
            # ...
            # ...

            # Each run will be done 4 times
            (1..4) | ForEach-Object {
                # The test itself (finally !!)
                # Rest of the code remains unchanged
                # ...
                # ...

                # Increment the counter and check if we reached the desired number of tests
                $counter++
                if ($counter -ge $NumberOfTests) {
                    Write-Host "Test completed after $NumberOfTests tests."
                    return
                }
            }
        }
    }
}


 





Set-location -Path $PSScriptRoot
# Check if data.csv already exists
$destinationPath = Join-Path $mydownloads "data.csv"
if (Test-Path $destinationPath) {
    # Append a unique number to the filename to avoid overwriting
    $count = 1
    while (Test-Path $destinationPath) {
        $destinationPath = Join-Path $mydownloads "data_$count.csv"
        $count++
    }
}

# Rename output.txt to data.csv
$sourcePath = Join-Path $mydownloads "output.txt"
Move-Item -Path $sourcePath -Destination $destinationPath


Param (

[string]$Global:disk 


)
 

}



$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot

clear-host
Write-host "Welcome to 4 corners storage test baseline"

 
Set-Location  "$mydownloads\CornersTestandGraph\"

Rename-Item -Path "diskspd.__e" -NewName "diskspd.exe"
#Rename-Item -Path "DskSpd4C.ps1.renameme" -NewName "DskSpd4C.ps1"

$global:disk = read-host "If your ready and you have a specific hard drive in mind, type it now with a colon: Ex. D:"

Write-host " Spinning up Test engine.. Please wait.. "
Sleep (4)

###Below is form action 
######################################################################################################################


#corner1 $global:disk
 

#region Main Form

$mydownloads = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$myscriptloc = $PSScriptRoot
set-loc $myscriptloc

$menuArray = "4Corner", "Long Full" ,"test4K"

    
$tracearray = "Graphall", "randomIOPS", "SeqThroughPut"
$performarray = "randomIOPS","SeqThroughPut"
$SupportArray = "randomIOPS","SeqThroughPut"
$Form = New-Object System.Windows.Forms.Form
$Form.Width = 782
$Form.Height = 303
$Form.Text = ".\cornerstestandgraph.ps1"


#Oryx_Antelope
$Image = [system.drawing.image]::FromFile("$($PSScriptRoot)\r.jpg")
$backgroundImage = $Image
$form.width = 1200
$form.height = 400
$form.Text = ”.\cornerstestandgraph.ps1”
## DROPDOWN TO CHOOSE COURSE OF COMMANDS 
$form.AutoSize = $false
$form.BackgroundImage = $Image
$form.BackgroundImageLayout = "None"
 # None, Tile, Center, Stretch, Zoom
$form.Width = $Image.Width
$form.Height = $Image.Height
$Font = New-Object System.Drawing.Font("Times New Roman",11,[System.Drawing.FontStyle]::Regular)
 # Font styles are: Regular, Bold, Italic, Underline, Strikeout
$form.TransparencyKey = $backgroundImage.GetPixel(100, 100)
$form.Font = $Font

# Create the first dropdown
$DropDown1 = New-Object System.Windows.Forms.ComboBox
$DropDown1.Location = New-Object System.Drawing.Size(150, 39)
$DropDown1.Size = New-Object System.Drawing.Size(133, 19)
$Dropown1.TransparencyKey = $backgroundImage.GetPixel(82, 29)
$DropDown1.BackColor = $backgroundImage.GetPixel(92,39)

# Create the second dropdown
$secondDropDown = New-Object System.Windows.Forms.ComboBox
$secondDropDown.Location = New-Object System.Drawing.Size(150, 79)
$secondDropDown.Size = New-Object System.Drawing.Size(146, 19)
$secondDropDown.TransparencyKey = $backgroundImage.GetPixel(83, 89)
$secondDropDown.BackColor = $backgroundImage.GetPixel(83,89)

$DropDown1.Items.AddRange($menuArray)

# Create the timecost label (moved outside the event handler)
$timecost = New-Object System.Windows.Forms.Label
$timecost.Location = New-Object System.Drawing.Size(330, 80)
$timecost.Size = New-Object System.Drawing.Size(500, 30)
$Font = New-Object System.Drawing.Font("Times New Roman", 14, [System.Drawing.FontStyle]::Bold)
$timecost.Font = $Font
$timecost.TransparencyKey = $backgroundImage.GetPixel(100, 500)
$timecost.BackColor = $backgroundImage.GetPixel(100, 400)
$Form.Controls.Add($timecost)



# Add event handler to first dropdown
$DropDown1.Add_SelectedIndexChanged({
    $selectedValue = $DropDown1.SelectedItem.ToString()
     
    $secondDropDown.Items.Clear()

    switch ($selectedValue) {
        '4Corner' {
            $secondDropDown.Items.AddRange($tracearray)
            $gettime = "20"
            $timecost.Text = "Test runs for at least $gettime Minutes"
        }
        'Long Full' {
            $secondDropDown.Items.AddRange($performarray)
            $gettime = "55"
            $timecost.Text = "Test runs for at least $gettime Minutes"
        }
        'test4K' {
            $secondDropDown.Items.AddRange($SupportArray)
            $gettime = "30"
            $timecost.Text = "Test runs for at least $gettime Minutes"
        }
    }
    $secondDropDown.Enabled = $true




})

$Form.Controls.Add($DropDown1)
$Form.Controls.Add($secondDropDown)

$DropDownLabel = New-Object System.Windows.Forms.Label
$DropDownLabel.Location = New-Object System.Drawing.Size(1, 39)
$DropDownLabel.Size = New-Object System.Drawing.Size(115, 20)
$DropDownLabel.TransparencyKey = $backgroundImage.GetPixel(20,30)
$DropDownLabel.BackColor = $backgroundImage.GetPixel(20,30)
$DropDownLabel.Text = "Type Test"
$Form.Controls.Add($DropDownLabel)

$secondLabel = New-Object System.Windows.Forms.Label
$secondLabel.Location = New-Object System.Drawing.Size(1, 80)
$secondLabel.Size = New-Object System.Drawing.Size(150, 20) 

$SecondLabel.TransparencyKey = $backgroundImage.GetPixel(82, 89)
$SecondLabel.BackColor = $backgroundImage.GetPixel(82, 89)
$secondLabel.Text = "Type of Report"
$Form.Controls.Add($secondLabel)
 

$Button = New-Object System.Windows.Forms.Button
$Button.Location = New-Object System.Drawing.Size(310, 29)
$Button.Size = New-Object System.Drawing.Size(240, 29)
$Button.Text = "Start Test Disk $global:disk"



$Button.Add_Click({
    # Handle the button click event
     
    $disktest1 = $DropDown1.SelectedItem.ToString()
    $disktest2 = $secondDropDown.SelectedItem.ToString()
   
 
   
   switch ($disktest1) {
        '4Corner' {
             actualcorner $global:disk
            
             
        }
        'Long Full' {
           corner1 $global:disk
           
        }
        'Singletest' {
           Singletest $global:disk
           
        }
    }
    $secondDropDown.Enabled = $true

   



})
$Form.Controls.Add($Button)

# Import the requiYellow namespace for keyboard handling
Add-Type -TypeDefinition @'
    using System;
    using System.Windows.Forms;
    
    public class KeyboardHandler : IMessageFilter
    {
        private const int WM_KEYDOWN = 0x0100;
        private const int VK_ESCAPE = 0x1B;

        public bool PreFilterMessage(ref Message m)
        {
            if (m.Msg == WM_KEYDOWN && (int)m.WParam == VK_ESCAPE)
            {
                Application.return();
                return true;
            }
            return false;
        }
    }
'@

# Create an instance of the keyboard handler and add it as a message filter
$keyboardHandler = New-Object -TypeName KeyboardHandler
[System.Windows.Forms.Application]::AddMessageFilter($keyboardHandler)

$secondButton = New-Object System.Windows.Forms.Button
$secondButton.Location = New-Object System.Drawing.Size(600, 43)
#235 151
$secondButton.Size = New-Object System.Drawing.Size(160, 30)
$secondButton.Text = "Open Graph"
$secondButton.Add_Click({ 
 
      $disktest2 = $secondDropDown.SelectedItem.ToString()
    # Resize the PictureBox control to fit the form size
    ResizePictureBox
        
    $Checking = test-path -path "$mydownloads\CornersTestandGraph\$disktest2"
if ($Checking -eq "True")
 
 {
 
 # Display the image in the PictureBox control
    $imagePath = "$mydownloads\CornersTestandGraph\$disktest2.png"  # Replace this with the path to your .bmp image
    $image = [System.Drawing.Image]::FromFile($imagePath)
    $pictureBoxImage.Image = $image
    $timecost.Text = "Graph Displayed from PS root Script folder"
 
 } else {
 $timecost.Text = "Graph Viewable when tests done and graph.png generated"
 $variable = "$global:disk"
 & $disktest2 -Name $variable

 
 

 $timecost.text = "Running Graph processing"

    $imagePath = "$mydownloads\CornersTestandGraph\$disktest2.png"  # Replace this with the path to your .bmp image
    $image = [System.Drawing.Image]::FromFile($imagePath)
    $pictureBoxImage.Image = $image
    $timecost.Text = "Graph Displayed from PS root Script folder"



  }
    
})

 

$Form.Controls.Add($secondButton)



$thirdButton = New-Object System.Windows.Forms.Button
$thirdButton.Location = New-Object System.Drawing.Size(600, 5)

$thirdButton.Size = New-Object System.Drawing.Size(160, 25)
$thirdButton.Text = "Terminate and return"
$thirdButton.Add_Click({ closeall })
$Form.Controls.Add($thirdButton)

 



$DropDownLabel2 = New-Object System.Windows.Forms.Label
$DropDownLabel2.Location = New-Object System.Drawing.Size(1, 10)
$DropDownLabel2.Size = New-Object System.Drawing.Size(125, 20)
$DropDownLabel2.TransparencyKey = $backgroundImage.GetPixel(10, 10)
$DropDownLabel2.BackColor = $backgroundImage.GetPixel(21,15)
$Font = New-Object System.Drawing.Font("Times NewRoman", 11, [System.Drawing.FontStyle]::Bold)
$DropDownLabel2.font = $font
$DropDownLabel2.Text = "DiskSpd Testing"
$Form.Controls.Add($DropDownLabel2)
#########################################

 
# Create the PictureBox control
$pictureBoxImage = New-Object System.Windows.Forms.PictureBox
$pictureBoxImage.Size = New-Object System.Drawing.Size($Form.Width - 100, $Form.Height * 0.75)  # Adjust the size as needed
$pictureBoxImage.SizeMode = 'Zoom'  # Set the PictureBoxSizeMode to 'Zoom' to fit the image within the control

# Calculate the location to center the PictureBox horizontally from the bottom
$centerX = ($Form.Width - $pictureBoxImage.Width) / 2
$pictureBoxImage.Location = New-Object System.Drawing.Point($centerX, $Form.Height * 0.25)

# Add the PictureBox control to the form
$Form.Controls.Add($pictureBoxImage)

 

 



$Form.Add_Shown({ $Form.Activate() })
[void] $Form.ShowDialog()

#endregion Main Form

$form.close()
$form.dispose()