﻿# Drive performance Report Generator
# Original by Arnaud TORRES, Edited by Hans Lenze Kaper on 25 - sep - 2015
 $ErrorActionPreference = 'silentlycontinue'
 $WarningPreference = 'silentlycontinue'
# Clear screen
Clear-host
 
write-host "DRIVE PERFORMANCE REPORT GENERATOR" -foregroundcolor green
write-host "Script will stress your computer CPU and storage layer (including network if applicable!), be sure that no critical workload is running" -foregroundcolor yellow
 
# Disk to test
$Disk = Read-Host 'Which path would you like to test? (example - C:\ClusterStorage\Volume1 or \\fileserver\share or S:) Without the trailing \'
 
# Reset test counter
$counter = 0
 
# Use 1 thread / core
$Thread = "-t"+(Get-WmiObject win32_processor).NumberofCores
 
# Set time in seconds for each run
# 10-120s is fine
$TimeInput = Read-Host 'Duration: How long should each run take in seconds? (example - 60)'
$Time = "-d"+$TimeInput

# Choose how big the benchmark file should be. Make sure it is at least two times the size of the available cache. 
$capacity = Read-Host 'Testfile size: How big should the benchmark file be in GigaBytes? At least two times the cache size (example - 100)'
$CapacityParameter = "-c"+$Capacity+"G"
 
# Get date for the output file
$date = get-date
 
# Add the tested disk and the date in the output file
"Command used for the runs .\diskspd.exe -c[testfileSize]G -d[duration] -[randomOrSequential] -w[%write] -t[NumberOfThreads] -o[queue] -b[blocksize] -h -L $Disk\DiskStress\testfile.dat, $date" >> ./output.txt
 
# Add the headers to the output file
"Test N#, Drive, Operation, Access, Blocks, QueueDepth, Run N#, IOPS, MB/sec, Latency ms, CPU %" >> ./output.txt
 
# Number of tests
# Multiply the number of loops to change this value
# By default there are : (4 queue depths) x (4 blocks sizes) X (3 for read 100%, 70/30 and write 100%) X (2 for Sequential and Random) X (4 Runs of each)
$NumberOfTests = 384
 
write-host "TEST RESULTS (also logged in .\output.txt)" -foregroundcolor yellow
 
# Begin Tests loops

# We will run the tests with 1, 8, 16 and 32 queue depth
(1,8,16,32) | ForEach-Object {
$queueparameter = ("-o"+$_)
$queue = ("QueueDepth "+$_)

# We will run the tests with 4K, 8K, 64K and 512K block
(4,8,64,512) | ForEach-Object {  
$BlockParameter = ("-b"+$_+"K")
$Blocks = ("Blocks "+$_+"K")
 
# We will do Read tests, 70/30 Read/Write and Write tests
  (0,30,100) | ForEach-Object {
      if ($_ -eq 0){$IO = "Read"}
      if ($_ -eq 30){$IO = "Mixed"}
      if ($_ -eq 100){$IO = "Write"}
      $WriteParameter = "-w"+$_
 
# We will do random and sequential IO tests
  ("r","si") | ForEach-Object {
      if ($_ -eq "r"){$type = "Random"}
      if ($_ -eq "si"){$type = "Sequential"}
      $AccessParameter = "-"+$_
 
# Each run will be done 4 times for consistency
  (1..4) | ForEach-Object {
      
      # The test itself (finally !!)
         $result = .\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $queueparameter $BlockParameter -h -L $Disk\TestDiskSpd\testfile.dat
      
      # Now we will break the very verbose output of DiskSpd in a single line with the most important values
      foreach ($line in $result) {if ($line -like "total:*") { $total=$line; break } }
      foreach ($line in $result) {if ($line -like "avg.*") { $avg=$line; break } }
      $mbps = $total.Split("|")[2].Trim() 
      $iops = $total.Split("|")[3].Trim()
      $latency = $total.Split("|")[4].Trim()
      $cpu = $avg.Split("|")[1].Trim()
      $counter = $counter + 1
 
      # A progress bar, for fun
      Write-Progress -Activity ".\diskspd.exe $CapacityPArameter $Time $AccessParameter $WriteParameter $Thread $queueparameter $BlockParameter -h -L $Disk\TestDiskSpd\testfile.dat" -status "Test in progress" -percentComplete ($counter / $NumberofTests * 100)
            
      # We output the values to the text file
      “Test $Counter,$Disk,$IO,$type,$Blocks,$queue,Run $_,$iops,$mbps,$latency,$cpu"  >> ./output.txt
 
      # We output a verbose format on screen
      “Test $Counter, $Disk, $IO, $type, $Blocks, $queue, Run $_, $iops iops, $mbps MB/sec, $latency ms, $cpu CPU"
}
}
}
} 
}