﻿# Begin Tests loops
$NumberOfTests = 16  # 4 tests (read random, read sequential, write random, write sequential) x 4 runs each

$QueueDepths = 1, 8, 16, 32
$BlockSizes = 4, 4, 4, 4   # 4k block size for all tests
$ReadWrite = 0, 0, 100, 100  # 0 for read, 100 for write
$RandomSequential = "r", "si", "r", "si"

$counter = 0

for ($i = 0; $i -lt $NumberOfTests; $i++) {
    $QueueDepth = $QueueDepths[$i % 4]
    $BlockSize = $BlockSizes[$i % 4]
    $ReadWriteValue = $ReadWrite[$i % 4]
    $RandomSequentialValue = $RandomSequential[$i % 4]

    if ($ReadWriteValue -eq 0) { $IO = "Read" }
    else { $IO = "Write" }

    if ($RandomSequentialValue -eq "r") { $type = "Random" }
    else { $type = "Sequential" }

    $queueparameter = ("-o" + $QueueDepth)
    $queue = ("QueueDepth " + $QueueDepth)

    $BlockParameter = "-b" + $BlockSize + "K"
    $Blocks = ("Blocks " + $BlockSize + "K")

    $WriteParameter = "-w" + $ReadWriteValue
    $AccessParameter = "-" + $RandomSequentialValue

    # Each run will be done 4 times for consistency
    for ($run = 1; $run -le 4; $run++) {
        # The test itself (finally !!)
        $result = .\diskspd.exe $CapacityParameter $Time $AccessParameter $WriteParameter "-t1" $queueparameter $BlockParameter -h -L "$Disk\TestDiskSpd\testfile.dat"

        # Now we will break the very verbose output of DiskSpd in a single line with the most important values
        foreach ($line in $result) {
            if ($line -like "total:*") { $total = $line; break }
        }
        foreach ($line in $result) {
            if ($line -like "avg.*") { $avg = $line; break }
        }
        $mbps = $total.Split("|")[2].Trim()
        $iops = $total.Split("|")[3].Trim()
        $latency = $total.Split("|")[4].Trim()
        $cpu = $avg.Split("|")[1].Trim()

        $counter++

        # A progress bar, for fun
        Write-Progress -Activity ".\diskspd.exe $CapacityParameter $Time $AccessParameter $WriteParameter -t1 $queueparameter $BlockParameter -h -L $Disk\TestDiskSpd\testfile.dat" -status "Test in progress" -percentComplete ($counter / $NumberOfTests * 100)

        # We output the values to the text file
        "Test $Counter,$Disk,$IO,$type,$Blocks,$queue,Run $run,$iops,$mbps,$latency,$cpu" >> ./output.txt

        # We output a verbose format on screen
        "Test $Counter, $Disk, $IO, $type, $Blocks, $queue, Run $run, $iops iops, $mbps MB/sec, $latency ms, $cpu CPU"
        
        if ($counter -ge $NumberOfTests) {
            break
        }
    }
}
