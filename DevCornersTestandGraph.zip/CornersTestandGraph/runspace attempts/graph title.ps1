﻿$ChartTitle = New-Object System.Windows.Forms.DataVisualization.Charting.Title
$ChartTitle.Text = 'Sequential =Mb/Sec (green,red) / IO = IOPS counts (blue,pink)'
$Font = New-Object System.Drawing.Font @('Microsoft Sans Serif','6', [System.Drawing.FontStyle]::Bold)
$ChartTitle.Font =$Font
$Chart.Titles.Add($ChartTitle)