﻿

## GET to run as ADMIN
# Get the ID and security principal of the current user account
$myWindowsID=[System.Security.Principal.WindowsIdentity]::GetCurrent()
$myWindowsPrincipal=new-object System.Security.Principal.WindowsPrincipal($myWindowsID)
 $global:RunTime
# Get the security principal for the Administrator role
$adminRole=[System.Security.Principal.WindowsBuiltInRole]::Administrator
 
# Check to see if we are currently running "as Administrator"
if ($myWindowsPrincipal.IsInRole($adminRole))
 
   {
   # We are running "as Administrator" - so change the title and background color to indicate this
   $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)"
   $Host.UI.RawUI.BackgroundColor = "DarkBlue"
   clear-host
 
   }
else
   {
   # We are not running "as Administrator" - so relaunch as administrator
 
   # Create a new process object that starts PowerShell
   $newProcess = new-object System.Diagnostics.ProcessStartInfo "PowerShell";
 
   # Specify the current script path and name as a parameter
   $newProcess.Arguments = $myInvocation.MyCommand.Definition;
 
   # Indicate that the process should be elevated
   $newProcess.Verb = "runas";
 
   # Start the new process
   [System.Diagnostics.Process]::Start($newProcess);
 
   # Exit from the current, unelevated, process
   exit
 
   }
  $global:Start_Time = get-date 
  # SCRIPT STARTS HERE 
  # sERVER SECTION OF SCRIPT IS LINE 43 TO 1099
 $global:mydom 
 $mydom = $env:USERDOMAIN
 $myuser= $Env:Username
# hide for a bit $global:creds = Get-Credential -UserName $mydom\$myuser -Message "Pop Creds for OMIMSWAC $Env:Username"
  #$cred=Get-Credential -Message " Enter Drac USER and Pass"
  # THIS IS A SIDE FUNCTION THAT INSTALLS WAC IN CLUSTER SERVICE MODE_ NOT DELL SUPPORTED 
 Function runmybs
  {
  
   Clear-host
  Write-host " THis is now a different purpose script. This section will do WAC setup only. This is not supprorted by Dell or anyone in support org or anyone else."
  Write-host " This is provided for free - from a public sourced article, for your own use. "
  # https://learn.microsoft.com/en-us/windows-server/manage/windows-admin-center/deploy/high-availability
  Write-host " take your support issues to MIctosoft for this script use, in accordance with the script and linke in this ps1"
Sleep(3)
  $iss2d -eq 0
  $iscluster = "a"
  $doinstall = read-host " Would you like to Deploy WAC on a cluster node and deploy as a service? This will install WAC on all nodes in cluster (y/n)"
  
 If ($doinstall -ieq 'y')
 {

  Function MSclusterwac
  {
  
  <#########################################################################################################
 # File: Install-WindowsAdminCenterHA.ps1
 #
 # .DESCRIPTION
 #
 #  Install Windows Admin Center as HA service.
 #
 #  Copyright (c) Microsoft Corp 2017.
 #
 #########################################################################################################>

<#
.SYNOPSIS

Install Windows Admin Center as HA service.

.DESCRIPTION

The Install-WindowsAdminCenterHA.ps1 script installs sme on all nodes in failover cluster and create a generic service role for it.

.PARAMETER MsiPath
Specifies the path of the Windows Admin Center msi installer.

.PARAMETER CertPath
Specifies the path for ssl certificate.

.PARAMETER CertPassword
Specifies the password for ssl certificate.

.PARAMETER GenerateSslCert
Generates a self signed ssl certificate.

.PARAMETER ClusterStorage
Specifies the path to the cluster shared volume.

.PARAMETER ClientAccessPoint
Specifies the name for client access point.

.PARAMETER PortNumber
Specifies the ssl port number.

.PARAMETER StaticAddress
Specifies one or more static addresses for the cluster generic service.

.EXAMPLE
.\Install-WindowsAdminCenterHA.ps1 -MsiPath '.\ServerManagementGateway.msi' -GenerateSslCert -ClusterStorage C:\ClusterStorage\Volume1 -ClientAccessPoint smeha-1

.EXAMPLE
$certPassword = Read-Host -AsSecureString
.\Install-WindowsAdminCenterHA.ps1 -MsiPath '.\ServerManagementGateway.msi' -CertPath test.pfx -CertPassword $CertPassword -ClusterStorage C:\ClusterStorage\Volume1 -ClientAccessPoint smeha-1

#>

#Requires -RunAsAdministrator

[CmdletBinding(DefaultParameterSetName='Upgrade', SupportsShouldProcess=$true, ConfirmImpact="Medium")]
param (
    [Parameter(ParameterSetName='InstallSpecifyCert', Mandatory = $true)]
    [Parameter(ParameterSetName='InstallGenerateCert', Mandatory = $true)]
    [Parameter(ParameterSetName='Upgrade', Mandatory = $true)]
    [Parameter(ParameterSetName='UpgradeSpecifyCert', Mandatory = $true)]
    [Parameter(ParameterSetName='UpgradeGenerateCert', Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [ValidateScript({
        if (Test-Path -Path $_ -PathType Leaf) {
            $true
        } else {
            throw "MsiPath '$_' is invalid or does not exist."
        }
    })]
    [String]
    $MsiPath = '.\ServerManagementGateway.msi',

    [Parameter(ParameterSetName='InstallSpecifyCert', Mandatory = $true)]
    [Parameter(ParameterSetName='UpgradeSpecifyCert', Mandatory = $true)]
    [Parameter(ParameterSetName='UpdateSpecifyCert', Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [ValidateScript({
        if (Test-Path -Path $_ -PathType Leaf) {
            $true
        } else {
            throw "CertPath '$_' is invalid or does not exist."
        }
    })]
    [String]
    $CertPath,

    [Parameter(ParameterSetName='InstallSpecifyCert', Mandatory = $true)]
    [Parameter(ParameterSetName='UpgradeSpecifyCert', Mandatory = $true)]
    [Parameter(ParameterSetName='UpdateSpecifyCert', Mandatory = $true)]
    [SecureString]
    $CertPassword,

    [Parameter(ParameterSetName='InstallGenerateCert', Mandatory = $true)]
    [Parameter(ParameterSetName='UpgradeGenerateCert', Mandatory = $true)]
    [Parameter(ParameterSetName='UpdateGenerateCert', Mandatory = $true)]
    [ValidateSet($true)]
    [switch]
    $GenerateSslCert,

    [Parameter(ParameterSetName='InstallSpecifyCert', Mandatory = $true)]
    [Parameter(ParameterSetName='InstallGenerateCert', Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [ValidateScript({
        if (Test-Path $_) {
            $true
        } else {
            throw "ClusterStorage path '$_' is invalid or does not exist."
        }
    })]
    [String]
    $ClusterStorage,

    [Parameter(ParameterSetName='InstallSpecifyCert', Mandatory = $true)]
    [Parameter(ParameterSetName='InstallGenerateCert', Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [ValidateScript({
        if (Test-Connection $_ -Count 1 -Quiet) {
            throw "Client access point '$_' is already in use (can be pinged)."
        }
        #elseif (Resolve-DnsName $_ -ErrorAction SilentlyContinue) {
        #    throw  "Client access point '$_' is already registered in DNS."
        #}
        else {
            $true
        }
    })]
    [String]
    $ClientAccessPoint,

    [Parameter(ParameterSetName='InstallSpecifyCert', Mandatory = $false)]
    [Parameter(ParameterSetName='InstallGenerateCert', Mandatory = $false)]
    [int]
    $PortNumber = 443,

    [Parameter(ParameterSetName='InstallSpecifyCert', Mandatory = $false)]
    [Parameter(ParameterSetName='InstallGenerateCert', Mandatory = $false)]
    [String[]]
    $StaticAddress,

    [Parameter(ParameterSetName='Uninstall', Mandatory = $true)]
    [switch]
    $Uninstall
)

function Trace-Execution {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $Message,

        [switch]
        $NoTimeStamp
    )

    if (-not $NoTimeStamp) {
        $Message = "$([DateTime]::Now.ToString("yyyy-MM-dd HH:mm:ss")) $Message"
    }

    Write-Verbose $Message
}

function Test-ShouldProcess {
    [CmdletBinding()]
    param (
        [string]
        $Message
    )
    
    $whatIf = (Get-PSCallStack).Arguments -join '' -match 'WhatIf=True'

    if ($whatIf) {
        Trace-Execution "WhatIf: $Message"
        return $false
    } else {
        Trace-Execution "$Message"
        return $true
    }
}

# Runs command as a scheduled task. The call returns as soon as command has started.
function Invoke-AsyncCommand {
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $ComputerName,

        [Parameter(Mandatory=$true)]
        [string]
        $TaskName,

        [Parameter(Mandatory=$true)]
        [string]
        $TaskPath,

        [Parameter(Mandatory=$true)]
        [string]
        $Execute,

        [Parameter(Mandatory=$false)]
        [string]
        $Argument
    )

    Invoke-Command -ComputerName $ComputerName -ScriptBlock {
        Import-Module ScheduledTasks
        $VerbosePreference = $using:VerbosePreference
        Write-Verbose "Unregister scheduled task '$using:TaskName', if it already exists." -Verbose:$using:clientVerbosePreference
        Get-ScheduledTask | ? TaskName -eq $using:TaskName | Unregister-ScheduledTask -Confirm:$false
        if ($using:Argument) {
            $action = New-ScheduledTaskAction -Execute $using:Execute -Argument:$using:Argument
        } else {
            $action = New-ScheduledTaskAction -Execute $using:Execute
        }
        Write-Verbose "Register scheduled task '$using:TaskName'." -Verbose:$using:clientVerbosePreference
        $principal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType S4U
        $task = Register-ScheduledTask -TaskName $using:TaskName -TaskPath $using:TaskPath -Action $action -Principal $principal -Force -Verbose:$false
        $startTime = [DateTime]::Now
        $secondsToStart = 10
        Write-Verbose "Start scheduled task '$using:TaskName'." -Verbose:$using:clientVerbosePreference
        $lastRunTime = $taskInfo.LastRunTime
        $taskHasStarted = $false
        $null = Start-ScheduledTask -InputObject $task
        while ([DateTime]::Now -lt $startTime.AddSeconds($secondsToStart)) {
            $taskInfo = Get-ScheduledTask | ?  TaskName -eq $using:TaskName | Get-ScheduledTaskInfo
            if ($taskInfo.LastRunTime -ne $lastRunTime) {
                Write-Verbose "Scheduled task '$using:TaskName' has started execution." -Verbose:$using:clientVerbosePreference
                $taskHasStarted = $true
                break
            }
        }
        if (-not $taskHasStarted) {
            Write-Error "Task '$using:TaskName' failed to start in $secondsToStart seconds."
        }
    }
}

function Install-WindowsAdminCenter {
    [CmdletBinding()]
    param (
        $certThumbprint, $PortNumber, $tempFolder, $certName, $CertPassword, [switch]$UseLocalMsi
    )

    $nodes = Get-ClusterNode

    foreach ($node in $nodes) {
        $computerName = $node.Name
        $installingMessage = "$script:msiMode Windows Admin Center on '$computerName'."
        Write-Host $installingMessage -ForegroundColor Green
        
        if (Test-ShouldProcess $installingMessage) {
            if ($certName) {
                Trace-Execution "Install certificate"
                Invoke-Command -ComputerName $computerName {
                    $null = Import-PfxCertificate -FilePath "$using:tempFolder\$using:certName" -Password $using:certPassword -CertStoreLocation Cert:\LocalMachine\My
                }
            }

            Trace-Execution "Start Windows Admin Center MSI install."
            $taskName = 'InstallWindowsAdminCenterHA'
            $wacProductInfo = Get-WmiObject Win32_Product -ComputerName $computerName | ? Name -eq $WAC_PRODUCT_NAME
            if ($UseLocalMsi) {
                $MsiPath = $wacProductInfo.LocalPackage
            } else {
                $MsiPath = "$tempFolder\ServerManagementGateway.msi"
            }
            $logPath = "$tempFolder\sme-$computerName.log"
            $msiArgumentString = "/qn /l*v `"$logPath`" SME_PORT=$PortNumber SSL_CERTIFICATE_OPTION=installed SME_THUMBPRINT=$certThumbprint"
            if ($wacProductInfo) {
                $msiArgumentString += " REINSTALLMODE=amus REINSTALL=ALL"
            }

            Trace-Execution "Start MSI install - $MsiPath $msiArgumentString"
            $asyncCommandParameters = @{
                ComputerName = $computerName
                TaskName = $taskName
                TaskPath = '\Microsoft\WindowsAdminCenter'
                Execute = $MsiPath
                Argument = $msiArgumentString
            }
            Invoke-AsyncCommand @asyncCommandParameters
        }
    }
    foreach ($node in $nodes) {
        $computerName = $node.Name
        $minutesToInstall = 10
        $waitingMessage = "Wait for $minutesToInstall minutes for MSI to install on $computerName."
        Write-Host $waitingMessage -ForegroundColor Green
        if (Test-ShouldProcess $waitingMessage) {
            $endTime = [DateTime]::Now.AddMinutes($minutesToInstall)
            $taskComplete = $null
            while ([DateTime]::Now -lt $endTime) {
                try {
                    $taskInfo = Invoke-Command -ComputerName $computerName {
                        Get-ScheduledTask | ? TaskName -eq $using:taskName | Get-ScheduledTaskInfo
                    }
                    Trace-Execution "Task last run result at $([DateTime]::Now.ToString('HH:mm:ss')) is $($taskInfo.LastTaskResult)"
                    if ($taskInfo.LastTaskResult -eq 0) {
                        $taskComplete = $true
                    }

                } catch {
                    # Ignoring exceptions as the remote call is expected break some time during WAC installation due to winrm reconfiguration.
                }
                if ($taskComplete) {
                    break
                }
                if ($taskInfo.LastTaskResult -eq 1603) {
                    Write-Error "MSI installation failed with the code 'Fatal Error During Installation' (1603)."
                }
                if ($taskInfo.LastTaskResult -eq 1618) {
                    Write-Error "MSI installation failed with the code ERROR_INSTALL_ALREADY_RUNNING (1618)."
                }
                if ($taskInfo.LastTaskResult -eq 1641) {
                    Write-Warning "You must restart your system for the configuration changes made to Windows Admin Center to take effect."
                    $taskComplete = $true
                    break
                }
                Start-Sleep -Seconds 10
            }

            if (-not $taskComplete) {
                Write-Error "Failed to install Windows Admin Center MSI on $computerName in $minutesToInstall minutes."
            }
        }
    
        if (Test-ShouldProcess "Change ServerManagementGateway service start mode to manual and stop the service.") {
            Invoke-Command -ComputerName $computerName {
                Set-Service ServerManagementGateway -StartupType Manual
            }
        }

        if (Test-ShouldProcess "Stop ServerManagementGateway service.") {
            Invoke-Command -ComputerName $computerName {
                Stop-Service ServerManagementGateway
            }
        }

        if (Test-ShouldProcess "Verify firewall rule was created.") {
            Invoke-Command -ComputerName $computerName {
                if (-not (Get-NetFirewallRule | ? DisplayName -eq SmeInboundOpenException)) {
                    Write-Verbose "Recreate firewall rule to allow inbound trafic." -Verbose:$using:clientVerbosePreference
                    $null = New-NetFirewallRule -DisplayName SmeInboundOpenException -Direction Inbound -LocalPort 443 -Protocol TCP -Action Allow -Description 'Windows Admin Center inbound port exception'
                }
            }
        }
    }
}

function Uninstall-WindowsAdminCenter {
    Write-Host "Uninstalling $WAC_PRODUCT_NAME." -ForegroundColor Green
   
    Trace-Execution "Get cluster resource for '$WAC_PRODUCT_NAME'."
    $wacClusterResource = Get-ClusterResource | ? Name -match $WAC_PRODUCT_NAME
    if ($wacClusterResource) {
        $ownerGroupName = $wacClusterResource.OwnerGroup.Name
        Trace-Execution "Remove cluster group $ownerGroupName."
        Remove-ClusterGroup $ownerGroupName -RemoveResources -Force
    }
    $nodeNames = Get-ClusterNode | % Name

    foreach ($nodeName in $nodeNames) {
        $uninstallMessage = "Uninstalling $WAC_PRODUCT_NAME on $nodeName."
        Write-Host $uninstallMessage -ForegroundColor Green
        if (Test-ShouldProcess $uninstallMessage) {
            Invoke-Command -ComputerName $nodeName -ScriptBlock {
                $queryResult = Get-WmiObject -Query "SELECT ProductCode FROM Win32_Property WHERE Property='UpgradeCode' AND Value='{af3e4932-2d63-46f8-a37f-b6acfd5378cd}'"
                if ($queryResult) {
                    $productCode = $queryResult.ProductCode
                    $app = Get-WmiObject Win32_Product -Filter "IdentifyingNumber='$productCode'"
                    if ($app) {
                        Write-Verbose "Running uninstall of $($app.Name)." -Verbose:$using:clientVerbosePreference
                        $app.UnInstall() | Out-Null
                    }
                }
                if (Test-Path $using:WAC_SETTINGS_REG_KEY) {
                    Write-Verbose "Remove registry settings at $using:WAC_SETTINGS_REG_KEY." -Verbose:$using:clientVerbosePreference
                    Remove-Item $using:WAC_SETTINGS_REG_KEY -Recurse
                }
            }
        }
    }
}

function Get-TempPassword {
    $length = 20
    $characterSet = [char]'0'..[char]'9' + [char]'A'..[char]'Z'
    $tempPassword = (1..$length | % {$characterSet | Get-Random} | % {[string][char]$_}) -join ''
    return $tempPassword
}

$ErrorActionPreference = "Stop"
$clientVerbosePreference = $VerbosePreference -ne 'SilentlyContinue'

$WAC_PRODUCT_NAME = 'Windows Admin Center'
$WAC_SETTINGS_REG_KEY = 'HKLM:\Software\Microsoft\ServerManagementGateway' 
$HA_SETTINGS_REG_KEY = "$WAC_SETTINGS_REG_KEY\ha"

if ($PSCmdlet.ParameterSetName -match 'Uninstall') {
    Uninstall-WindowsAdminCenter
    return
}

Trace-Execution "Selecting installation mode based on the specified parameters."
Write-Host "Installation mode is $($PSCmdlet.ParameterSetName)." -ForegroundColor Green

# $msiMode variable is used to provide descriptive messages on the way the MSI package gets applied - installing, upgrading, or just updating certificates.
if ($PSCmdlet.ParameterSetName -match 'Install') {
    $script:msiMode = 'Installing'
} elseif ($PSCmdlet.ParameterSetName -match 'Upgrade') {
    $script:msiMode = 'Upgrading'
} else {
    $script:msiMode = 'Updating'
}

if ($ClientAccessPoint) {
    # Assigning this parameter to a local variable to avoid parameter validation, when/if this value is modified.
    $accessPoint = $ClientAccessPoint
}

Trace-Execution "Get cluster resource for '$WAC_PRODUCT_NAME'."
$wacClusterResource = Get-ClusterResource | ? Name -match $WAC_PRODUCT_NAME

if ($wacClusterResource -or ($PSCmdlet.ParameterSetName -match 'Upgrade') -or ($PSCmdlet.ParameterSetName -match 'Update')) {
    if (-not $wacClusterResource) {
        Write-Error "Upgrade failed, reason - '$WAC_PRODUCT_NAME' cluster resource does not exist."
    }
    $ownerGroup = $wacClusterResource.OwnerGroup
    $ownerNodeName = $ownerGroup.OwnerNode.Name
    Trace-Execution "Retrieve gateway settings of the previous installation."
    $haSettings = Invoke-Command -ComputerName $ownerNodeName {
        Get-ItemProperty $using:HA_SETTINGS_REG_KEY
    }
    if (-not $haSettings) {
        Write-Error "Failed to retrieve gateway settings of the previous installation from $ownerNodeName, registry key '$HA_SETTINGS_REG_KEY'."
    }
    $storagePath = $haSettings.StoragePath
    Trace-Execution "StoragePath = $storagePath"
    $certThumbprint = $haSettings.Thumbprint
    Trace-Execution "Thumbprint = $certThumbprint"
    Trace-Execution "Port = $($haSettings.Port)"
    Trace-Execution "ClientAccessPoint = $($haSettings.ClientAccessPoint)"
    if ($haSettings.StaticAddress) {
        Trace-Execution "StaticAddress = $StaticAddress"
    } else {
        Trace-Execution "StaticAddress is not defined."
    }

    # Settings passed from parameters override values stored in registry.
    if (-not $ClusterStorage) {
        $ClusterStorage = (Get-Item $storagePath).Parent.FullName
    }
    Trace-Execution "ClusterStorage value to be used - $ClusterStorage"
    if (-not $accessPoint) {
        $accessPoint = $haSettings.ClientAccessPoint
    }
    Trace-Execution "ClientAccessPoint value to be used - $accessPoint"
    if (-not $PortNumber) {
        $PortNumber = $haSettings.Port
    }
    Trace-Execution "Port value to be used - $PortNumber"
    if (-not $StaticAddress) {
        $StaticAddress = $haSettings.StaticAddress.Split(',')
    }
    Trace-Execution "StaticAddress value to be used - $StaticAddress"

    if (Test-ShouldProcess "Remove cluster group for the previous installation - $accessPoint.") {
        Remove-ClusterGroup $haSettings.ClientAccessPoint -RemoveResources -Force
    }
}

$matchingClusterVolume = Get-ClusterSharedVolume | ForEach-Object -WhatIf:$false SharedVolumeInfo | ForEach-Object -WhatIf:$false FriendlyVolumeName | ? {$ClusterStorage -like "$_*"}

if (-not $matchingClusterVolume) {
    Write-Error "Specified cluster storage '$ClusterStorage' does not belong to a cluster shared volume."
}

$tempFolder = "$ClusterStorage\temp"
Trace-Execution "Create temporary folder for the installation - '$tempFolder'."
$null = New-Item $tempFolder -Type Directory -Force

if ($PSCmdlet.ParameterSetName -match 'Cert') {
    if ($GenerateSslCert) {
        Trace-Execution "Creating self-signed certificate."
        $domain = (Get-WmiObject win32_computersystem).Domain
        $dnsName = "$accessPoint.$domain"
        $cert = New-SelfSignedCertificate -DnsName $dnsName -CertStoreLocation "cert:\LocalMachine\My" -NotAfter (Get-Date).AddMonths(3) -WhatIf:$false
        $tmpPassword = Get-TempPassword
        $CertPassword = ConvertTo-SecureString -String $tmpPassword -Force -AsPlainText
        $certificatePath = "$PSScriptRoot\sme.pfx"
        $null = $cert | Export-PfxCertificate -FilePath $certificatePath -Password $CertPassword -WhatIf:$false
    } else{
        $certificatePath = Resolve-Path $CertPath
        Trace-Execution "Import certificate from '$certificatePath'."
        $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2
        $cert.Import($certificatePath, $CertPassword, 'DefaultKeySet')
    }

    $certName = Split-Path $certificatePath -Leaf
    $certThumbprint = $cert.Thumbprint
    Trace-Execution "Certificate thumbprint to be used - '$certThumbprint'."

    Trace-Execution "Copy certificate file to the temporary shared folder."
    Copy-Item -Path $certificatePath -Destination $tempFolder -Force
}

$nodes = Get-ClusterNode

if ($PSCmdlet.ParameterSetName -notmatch 'Update') {
    Trace-Execution "Copy installation file to the temporary shared folder."
    Copy-Item -Path $MsiPath -Destination "$tempFolder\ServerManagementGateway.msi" -Force
}

if ($PSCmdlet.ParameterSetName -match 'Cert') {
    if ($PSCmdlet.ParameterSetName -match 'Update') {
        Install-WindowsAdminCenter $certThumbprint $PortNumber $tempFolder $certName $CertPassword -UseLocalMsi
    } else {
        Install-WindowsAdminCenter $certThumbprint $PortNumber $tempFolder $certName $CertPassword
    }
} else {
    Install-WindowsAdminCenter $certThumbprint $PortNumber $tempFolder
}

Write-Host "Configuring Windows Admin Center gateway." -ForegroundColor Green

if (Test-ShouldProcess "Adding Cluster Generic Service Role '$accessPoint'") {
    if ($StaticAddress) {
        $role = Add-ClusterGenericServiceRole -ServiceName ServerManagementGateway -Name $accessPoint -StaticAddress $StaticAddress
    } else {
        $role = Add-ClusterGenericServiceRole -ServiceName ServerManagementGateway -Name $accessPoint
    }
}

$ownerNodeName = $role.OwnerNode.Name
if (Test-ShouldProcess "Configure $WAC_PRODUCT_NAME on the owner node $ownerNodeName.") {
    $smePath = "$ClusterStorage\Server Management Experience"
    $command = { 
        param (
            $smePath, $certThumbprint, $PortNumber, $accessPoint, $StaticAddress
        )

        Write-Verbose "Copying files to cluster storage: $smePath" -Verbose:$using:clientVerbosePreference
        $uxFolder = "$smePath\Ux"
        if (Test-Path $uxFolder) {
            Remove-Item $uxFolder -Force -Recurse
        }
        New-Item -Path $uxFolder -ItemType Directory | Out-Null

        Copy-Item -Path "$env:programdata\Server Management Experience\Ux" -Destination $smePath -Recurse -Container -Force

        Write-Verbose "Saving settings to registry: $using:HA_SETTINGS_REG_KEY" -Verbose:$using:clientVerbosePreference
        $registryPath = $using:HA_SETTINGS_REG_KEY
        $null = New-Item -Path $registryPath -Force
        New-ItemProperty -Path $registryPath -Name IsHaEnabled -Value "true" -PropertyType String -Force | Out-Null
        New-ItemProperty -Path $registryPath -Name StoragePath -Value $smePath -PropertyType String -Force | Out-Null
        New-ItemProperty -Path $registryPath -Name Thumbprint -Value $certThumbprint -PropertyType String -Force | Out-Null
        New-ItemProperty -Path $registryPath -Name Port -Value $PortNumber -PropertyType String -Force | Out-Null
        New-ItemProperty -Path $registryPath -Name ClientAccessPoint -Value $accessPoint -PropertyType String -Force | Out-Null
        $StaticAddressValue = $StaticAddress -join ','
        New-ItemProperty -Path $registryPath -Name StaticAddress -Value $StaticAddressValue -PropertyType String -Force | Out-Null
        Add-ClusterCheckpoint -ResourceName $accessPoint -RegistryCheckpoint "SOFTWARE\Microsoft\ServerManagementGateway\Ha" | Out-Null
    
        Write-Verbose "Grant permissions to Network Service for the UX folder." -Verbose:$using:clientVerbosePreference
        $Acl = Get-Acl $uxFolder
	    $sID = New-Object System.Security.Principal.SecurityIdentifier("S-1-5-20")
        $Ar = New-Object  system.security.accesscontrol.filesystemaccessrule($sID, "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
        $Acl.SetAccessRule($Ar)
        Set-Acl $uxFolder $Acl

        Write-Verbose "Restart ServerManagementGateway service." -Verbose:$using:clientVerbosePreference
        Restart-Service ServerManagementGateway
    }

    Invoke-Command -ComputerName $ownerNodeName -ScriptBlock $command -ArgumentList $smePath, $certThumbprint, $PortNumber, $accessPoint, $StaticAddress
}

Trace-Execution "Installation is complete."

  
  
  }
  }

  }

# This is the Cluster section of the Script. These sections will only run on the cluster

$cluster = Get-WMIObject -Class MSCluster_Cluster -ComputerName $env:computername -Namespace root\mscluster -WarningAction SilentlyContinue -ErrorAction SilentlyContinue
$iss2d = $cluster.S2DEnabled
$iscluster= (get-cluster).ClusterFunctionalLevel

 ### THIS IS A side step of the server code. this is for later use to do some deployment work. 
 If (($iss2d -eq 1) -and ($iscluster -gt 8))
 {
 $mybs= "non"
# Write-host "This Script will Review a Deployment for OMIWAC. Run this script on one cluster node and also the WAC server. "
 #write-host " This is your one chance to go into an unsupported setup section. You will be responsible for this setup. "
 $mybs= Read-host "Hit Enter to begin the supported corrections script, or type the word Iknow as one word to enter the setup script. "
 read-host " Hit enter again to begin. You should run this on the wac machine first. IT can push needed files to this server, to complete setup."
 if ($mybs -eq "iknow") {runmybs}
 }
 ### THIS IS WHERE THE BULK OF THE SERVER CODE IS LOCATED. THIS IF CONTAINS THE SERVER FUNCTION
if (($iss2d -eq 1) -and ($iscluster -gt 8))
 {
 Write-host " This is a cluster node. moving to cluster logic" -ForegroundColor Green
 If ($iss2d -eq 1) {Write-host " Special S2d Edition. Moving to logic" -ForegroundColor Green}
  
sleep(2)
CLEAR-HOST
 $myspanse = (get-cluster)
 $myspanser = $myspanse

 
#install Idractools and Ism
Function ISMRAC {



$readme23 = Read-host " If isminstall.exe and racadmininstall.exe are sitting in downloads folder of servers- this will install them. Ready? y/n"


if ($readme23 -like "y")
{
 
set-location "$Env:Userprofile\downloads"
Invoke-command -computername (get-clusternode).name -scriptblock {

set-location "$Env:Userprofile\downloads"
$installed = $false
while (!$installed) {
$installed = test-path  "C:\Program Files\Dell\SysMgt\iSM\OSCollector\config\"
  Try{
      Write-Host "Expanding ISM..."
$process = Start-Process -FilePath "$Env:Userprofile\downloads\isminstall.exe" -ArgumentList "-auto" -Wait -PassThru -ErrorAction SilentlyContinue -ErrorVariable ISMExtractFail}
Catch { Write-Host "ERROR: Failed to isntall RADAdmin Tools. $ISMExtractFail" -ForegroundColor Red}




  Try{ Write-Host "Installing ISM..."
 Start-Process -FilePath "C:\OpenManage\iSM\windows\iDRACSvcMod.msi" -ArgumentList '/quiet /norestart' -Wait -ErrorAction SilentlyContinue -ErrorVariable ISMInstallFail}
 Catch {Write-Host "ERROR: Failed to isntall RADAdmin Tools. $ISMInstallFail" -ForegroundColor Red}
 $readme23 = "y"


    $installerService = Get-Service -Name msiserver
    if ($installerService.Status -eq 'Running') {
        #Write-Host "Windows Installer service is running. Waiting for completion."
        Start-Sleep -Seconds 10
        $installed = test-path  "C:\Program Files\Dell\SysMgt\iSM\OSCollector\config\"
    }
    else {
        Write-Host "Windows Installer service is not running. Assuming installation is complete."
        $installed = $true
    }
}

}


}
#Install Dractools
if ($readme23 -like "y")
{

Invoke-command -computername (get-clusternode).name -scriptblock {

set-location "$Env:Userprofile\downloads"
try{
Write-Host "Expanding iDracTools..."
$process2 = Start-Process -FilePath "$Env:Userprofile\Downloads\racadmininstall.exe" -ArgumentList "/auto" -Wait -PassThru -ErrorAction SilentlyContinue -ErrorVariable RACAdminExtractFail}
catch{Write-host " RACAdminExtractFail Error "}

$installed2 = $false
$installed2 = test-path "C:\Program Files\Dell\SysMgt\iDRACTools\racadm\"
 
while (!$installed2) {

Set-Location -Path "C:\OpenManage"
Write-Host "Installing iDracTools...For several machines it could be 20 min. Go have a break and come back in 15Min"
try {Start-Process -FilePath "C:\OpenManage\iDRACTools_x64.msi" -ArgumentList '/quiet /norestart' -Wait -ErrorAction SilentlyContinue -ErrorVariable ISMInstallFail
} Catch {-Wait -ErrorAction SilentlyContinue -ErrorVariable ISMInstallFail}
 
     $installerService2 = Get-Service -Name msiserver
    if ($installerService2.Status -eq 'Running') {
        #Write-Host "Windows Installer service is running. Waiting for completion."
        Start-Sleep -Seconds 10
        $installed2 = test-path "C:\Program Files\Dell\SysMgt\iDRACTools\racadm\"
    }
    else {
        Write-Host "Windows Installer service is not running. Assuming installation is complete."
        $installed2 = $true
    }
}

 # set-location "C:\Program Files\Dell\SysMgt\iDRACTools\racadm\"
  #  .\racadm.exe set idrac.servicemodule.osinfo 1           
   ###       stop-Service -Name msiserver


}
}


}

 Function Dracnic {


Invoke-Command -ComputerName (Get-ClusterNode).name -ScriptBlock { 

 

 $mydrac = Get-PcsvDevice 
$myredfish = $mydrac.IPv4Address
$myredfishDelta = ($myredfish -split '\.')[-1]
 
set-location  "C:\Program Files\dell\SysMgt\iDRACTools\racadm\" 

$newFish= "169.254.2.$myredfishDelta"

.\racadm get iDRAC.OS-BMC.UsbNicIpAddress 
.\racadm set iDRAC.OS-BMC.UsbNicIpAddress $newfish


#[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls -bor [Net.SecurityProtocolType]::Tls11 -bor [Net.SecurityProtocolType]::Tls12
#add-type @"
#    using System.Net;
##    using System.Security.Cryptography.X509Certificates;
 #   public class TrustAllCertsPolicy : ICertificatePolicy {
 #       public bool CheckValidationResult(
 #           ServicePoint srvPoint, X509Certificate certificate,
 #           WebRequest request, int certificateProblem) {
 #           return true;
 #       }
 #   }
#"@
#[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
#$header = @{'Content-Type'='application/json'; 'Accept'='application/json'}
#$url = "https://$myredfish/redfish/v1/Managers/iDRAC.Embedded.1/Oem/Dell/DellAttributes/iDRAC.Embedded.1"

#$response = Invoke-WebRequest -Uri $url -Method Get -Headers $header -Credential $cred -UseBasicParsing
#$data = ($response.Content | ConvertFrom-Json)
#$data.Attributes.'OS-BMC.1.UsbNicIpAddress'
 
#Patch
#$body=@'
{
#"Attributes":{
#"OS-BMC.1.UsbNicIpAddress":"169.254.10.$myredfishDelta"}
}
#'@
#$response = Invoke-WebRequest -Uri $url -Method Patch -Headers $header -Body $body -Credential $cred -UseBasicParsing


}

#Write Disable USB nic from cluster communication 
#Object 2 Disable CLus Comms for USB network

}

#disable cluster communication for idrac nic
Function cluscom {
 #$global:RunTime = New-TimeSpan -Start $StartTime -End (get-date) 
 

# Write-host " This final step in this section will attempt to disable the USB nic from the cluster communication." -ForegroundColor white
# read-host "Read to begin? hit enter"
# Write-host "Please open cluster manager and confirm the USBNIC network is showing under networks." -ForegroundColor white
# Write-host " come back to step 2 after discovery if needed to diable cluster communication for the USBNIC network" -ForegroundColor white
# read-host "ready to begin? Hit enter"
 
 #Get-ClusterNetwork | Format-Table Name, Metric
$my169net = Get-ClusterNetwork | sort-object metric
$my169max = ($my169net| Select-Object -last 1)

#write-host "$my169max we are removing this network from cluster communications" -ForegroundColor Yellow
#Write-host "$my169max is the network we identified to remove from cluster communications. Please verify in the network section of cluster manager. this should be the NDIS compatible device nics" -ForegroundColor white
write-host $my169max| fl
$my169net| Select-Object -last 1 | fl

$myread69 = Read-host "please hit Y and enter to confirm this network is ok to disable for cluster communicationy/n"

#if ($myread69 -ilike '*y*') {$my169max.role = 0 } 
$my169max.role = 0
 
 Invoke-Command -ComputerName (Get-ClusterNode).name -ScriptBlock { 
$myusbnic1 = Get-NetAdapter -InterfaceDescription "Remote NDIS Compatible Device" -ErrorAction SilentlyContinue -WarningAction SilentlyContinue 

$myusbnic1| Disable-NetAdapter -Confirm:$false -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
$myusbnic1 | Enable-NetAdapter -Confirm:$false -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
}

#Write-host "USB Network now removed from cluster network communications"  -ForegroundColor white


#Individual nic covered in UG


$rndisAdapter = Get-NetAdapter -InterfaceDescription 'Remote NDIS Compatible Device' -ErrorAction SilentlyContinue -WarningAction SilentlyContinue

if ($rndisAdapter)

{
 

# Get the network adapter and associated cluster network
$adapterId = [Regex]::Matches($rndisAdapter.InstanceID, '(?<={)(.*?)(?=})').Value
$usbNICInterface = (Get-ClusterNetworkInterface).Where({$_.adapterId -eq $adapterId})
$usbNICClusterNetwork = $usbNICInterface.Network

# Disable Cluster communication on the identified cluster network
(Get-ClusterNetwork -Name $usbNICClusterNetwork.ToString()).Role = 0
}
}

#check for cluster registered 
Function getazurestack {

$clusterAZ = Get-WMIObject -Class MSCluster_Cluster -ComputerName $env:computername -Namespace root\mscluster -WarningAction SilentlyContinue -ErrorAction SilentlyContinue
$clusterAZ.Name
$iss2d = $clusterAZ.S2DEnabled
 $iscluster= $clusterAZ.ClusterFunctionalLevel
 $ref1= "10"

If ($iscluster -ge "11") 
{
Invoke-Command -ComputerName (Get-ClusterNode).name -ScriptBlock { 
#Object #3 Check for Get-Azure StackHCI
$myconnstate = (Get-AzureStackHCI | where-object {$_.ConnectionStatus -eq "Connected"})
$myconnstate.ConnectionStatus
#$myconnstate | Select-Object -ExpandProperty ConnectionStatus
$myregstat = (Get-AzureStackHCI | where-object {$_.Registrationstatus -eq "Registered"})
$myregstat.RegistrationStatus
}
}
}
#disable uac remote per user guide
Function Uacheck {

#Allow Remote UAC disable - all nodes 

#$mynodes = $myspanse | Get-ClusterNode

 
Invoke-Command -ComputerName (Get-ClusterNode).name -ScriptBlock { 

REG ADD HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v LocalAccountTokenFilterPolicy /t REG_DWORD /d 1 /f 

 # Create new items with values
New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name  'LocalAccountTokenFilterPolicy' -Value '1' -PropertyType 'DWORD' –Force

#other Credentials issues dealt with here 

Set-Executionpolicy -executionpolicy remotesigned -Force
Set-Item WSMan:\localhost\Client\TrustedHosts * -Force
 

Enable-WSManCredSSP -Role Client -Delegate $env:USERDNSDOMAIN -force
Enable-WSManCredSSP -Role Server -Force
Set-Item -Path WSMan:\localhost\MaxEnvelopeSizekb 8192 -Force
New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name AllowFreshCredentialsWhenNTLMOnly -Force
New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name 1 -Value * -PropertyType String -Force

} 

}
#verify CAU starts 
Function startCAU {

# Check CAU and start or clear up 

Get-ClusterResource | where-object {$_.ResourceType -eq "ClusterAwareUpdatingResource"} 
Get-ClusterResource | where-object {$_.ResourceType -eq "Distributed network name"}
 
$myCAUResource = Get-ClusterResource | where-object {$_.ResourceType -eq "ClusterAwareUpdatingResource"} | Start-clusterresource
$myDNNResource = Get-ClusterResource | where-object {$_.ResourceType -eq "Distributed network name"}| Start-clusterresource

If ($myCAUResource.State -notlike "online") {Set-CauClusterRole -PreUpdateScript $null -PostUpdateScript $null}

if ($myDNNResource.State -notlike "online") {Set-CauClusterRole -PreUpdateScript $null -PostUpdateScript $null}




}
#sets forgoten and easty to forget firewalls including the pre-req checker 445 issue
Function firewalsforgot{
# these are firewasls to make the pre-requsite checker issues go away
# 2 rules just check the firewall rule imstead of actual function 

# make sure path is there for powershell all nodes 
Invoke-Command -ComputerName (Get-ClusterNode).name -ScriptBlock {
[Environment]::SetEnvironmentVariable("PSModulePath","%SystemRoot%\system32\WindowsPowerShell\v1.0\Modules;" + ([Environment]::GetEnvironmentVariable("PSModulePath","User")),"User")
Set-NetFirewallRule -Name WINRM-HTTP-In-TCP-PUBLIC -RemoteAddress Any 
Set-NetFirewallRule -Name WINRM-HTTP-In-TCP -RemoteAddress Any
netsh advfirewall firewall set rule name="File and Printer Sharing (SMB-In)" new enable=Yes

Set-NetFirewallRule -Name WINRM-HTTP-In-TCP-PUBLIC -RemoteAddress Any
}

}
# enable credssp and test to wac from each node
 
Function CheckCredssp{

####################################################
### Author: Tomas Jeck - thank you github
## https://github.com/bolvua/Enable-WSManCredSSP/blob/master/Enable-WSMan.ps1

#Here just define your variable
$DomainUserName = $Env:Username
 
$RemotePassword = (Get-Credential $env:USERDOMAIN\$Env:Username -Message "domain creds for target")
$RemoteHostname = Read-host "Be ready to put the creds in for each host- annoying in advance- enter the Wac host we need to trust. Just the hostname trust for credssp."
#fix issue maybe https://learn.microsoft.com/en-us/powershell/scripting/learn/deep-dives/add-credentials-to-powershell-functions?view=powershell-7.3
$YourDomainName = $env:USERDNSDomain
 
 $global:mydom 
 $mydom = $env:USERDOMAIN
 $myuser= $Env:Username
# hide for a bit $global:creds = Get-Credential -UserName $mydom\$myuser -Message "Pop Creds for OMIMSWAC $Env:Username"
  #$global:cred=Get-Credential

#Create Credential variable
$Password = ConvertTo-SecureString $RemotePassword -AsPlainText -Force
$Credential = New-Object System.Management.Automation.PSCredential("$YourDomainName\$DomainUserName",$Password)
Invoke-Command -ComputerName (Get-ClusterNode).name -ScriptBlock { 

# Test Connection
if(!(Test-WsMan -Authentication Credssp -ComputerName "$RemoteHostname.$YourDomainName" -Credential $RemotePassword -ErrorAction SilentlyContinue))
{
    # Try to Enable-WSManCredSSP - If failed (can happen) will do it directly on registry keys
    try {
        $credSSP = Enable-WSManCredSSP -Role "Client" -DelegateComputer "*.$YourDomainName" -Force -ErrorAction SilentlyContinue
    }
    catch { "" }
    if(!($credSSP)){
        #in object $key can be added more than one record. Example @("wsman/*.$YourDomainName","wsman/*.$secondDomainName",..)
        $key = @("wsman/*.$YourDomainName")
        $mainpath = 'hklm:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation'
        if (!(Test-Path $mainpath)) {
            mkdir $mainpath
        }
        $AllowFreshCredentials = Get-ItemProperty -Path $mainpath  | where-Object {$_.AllowFreshCredentials -eq "1"}
        $AllowFreshCredentialsNTML = Get-ItemProperty -Path $mainpath  | where-Object {$_.AllowFreshCredentialsWhenNTLMOnly -eq "1"}
        if (!$AllowFreshCredentials){
            New-ItemProperty -Path $mainpath -Name AllowFreshCredentials -Value 1 -PropertyType Dword -Force
        }
        if (!$AllowFreshCredentialsNTML){
            New-ItemProperty -Path $mainpath -Name AllowFreshCredentialsWhenNTLMOnly -Value 1 -PropertyType Dword -Force
        }  
        $keypath = Join-Path $mainpath 'AllowFreshCredentials'
        $keypath2 = Join-Path $mainpath 'AllowFreshCredentialsWhenNTLMOnly'
        if (!(Test-Path $keypath)) {
            mkdir $keypath
        }
        if (!(Test-Path $keypath2)) {
            mkdir $keypath2
        }
        #create new Items for every object in keys
        $i = 1
        $key | ForEach-Object {
            New-ItemProperty -Path $keypath -Name $i -Value $_ -PropertyType String -Force
            New-ItemProperty -Path $keypath2 -Name $i -Value $_ -PropertyType String -Force
            $i++
        }
        #wait for write registry keys - not necessary
        Start-Sleep -Seconds 1
        #Enable WSManCredSSP second try
        Enable-WSManCredSSP -Role "Client" -DelegateComputer "*.$YourDomainName" -Force -ErrorAction SilentlyContinue
    }
}
# ---------------------------------------------

}  
} 
#bypass wsus as this is not supported for 22h2 HCIOS

function bypasswsus {
#https://learn.microsoft.com/en-us/azure-stack/hci/concepts/updates

$bookwsus = 0 

   try {$result = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'UseWUServer' -ErrorAction SilentlyContinue)
    if ($result.'UseWUServer') {
    $bookwsus = 1
    Write-Output "The server is using WSUS for updates."} else {
    $bookwsus =2
    Write-Output "The server is not using WSUS for updates."}
     } catch {
     $bookwsus =3
     Write-Output "Unable to determine if the server is using WSUS for updates."}
If ($bookwsus -eq 1) {$myansw3 = read-host "wsus detected. Choose y to disable and allow WAC to do updates, or n to continue y/n"}
If ($myans3 -like 'y')
{
if ($bookwsus -eq 1) {icm -ComputerName (Get-clusternode).name -ScriptBlock{

try
{

(Set-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'UseWUServer' -value 0 -ErrorAction SilentlyContinue)
Restart-Service wuauserv
# Wsus Define the WSUS server This is the check for the WSUS server currently
  get-ItemProperty -path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -name 'WUServer' -ErrorAction SilentlyContinue
} Catch {Write-Error $_.Exception.Message   }


}}
  }
}

ISMRAC
if ($readme23 -eq 'y') { Write-Host "✔ Repair Install Dractools and ism module" -ForegroundColor Green   } else {
 Write-Host "✘ This process can take more then 20 min. Just wait the script will move forward. " -ForegroundColor Green  } 

### THis is the end of script, just putting up results at this point
if (dracnic) { Write-Host "✔ Repair Assign IDRAC Uniqie REDFISH IP" -ForegroundColor Green   } else {
 Write-Host "✘ Failure Assign IDRAC Uniqie REDFISH IP" -ForegroundColor Red   } 
if (getazurestack){ Write-Host "✔ Checked for Azure Registration" -ForegroundColor Green   } else {
 Write-Host "✘ Failure Repair Azure Registration" -ForegroundColor Red   } 
If (cluscom){Write-Host "✔ Completed function: Disable Drac Network fron Cluster Communications" -ForegroundColor Green }
else { Write-Host "✘ Failure Repair Disable Drac Network fron Cluster Communications" -ForegroundColor Red   } 
if (CheckCredssp) {
Write-Host "✔ Completed function: Enable Credssp Trust" -ForegroundColor Green } else { Write-Host "✘ Test CredSSP Trust" -ForegroundColor Green   } 
if (firewalsforgot ) {
Write-Host "✔ Completed function: Firewall rules for pre-req checker to work " -ForegroundColor Green } else { Write-Host "✘ Failure Repair Firewall rules for pre-req checker to work" -ForegroundColor Red   } 
If(Uacheck) {Write-Host "✔ Finished up with Remote UAC enable " -ForegroundColor Green  } else { Write-Host "✘ Failure Repair  Remote UAC enable" -ForegroundColor Red   } 

 If(startCAU) { Write-Host "✔ Finished up with CAU check and start " -ForegroundColor Green   } else { Write-Host "✘ Failure to test CAU start" -ForegroundColor Red   } 
try{ (bypasswsus) 
Write-Host "✔ Repair Enable BYpass WSUS for updates" -ForegroundColor Green   } catch {Write-Host "✘ Failure BYpass WSUS for updates" -ForegroundColor Red   } 

  
}


####### BEGINING OF WAC CLIENT SECTION OF SCRIPT
#THIS IS TESTING FOR A CLUSTER LIKE THE SERVER SECTION BUT THE RESULTS ARE USED TO EXPRESS HOW WE KNOW TO THIS IS THE WAC MACHINE - 
$THEIRcluster = Get-WMIObject -Class MSCluster_Cluster -ComputerName $env:computername -Namespace root\mscluster -WarningAction SilentlyContinue -ErrorAction SilentlyContinue
$THEIRcluster.Name
$iss2d = $THEIRcluster.S2DEnabled
Write-host "cluster enabled is 0 for false or 1 for true" -NoNewline
$iss2d
 
$iscluster= $THEIRcluster.ClusterFunctionalLevel
# 1108-1334 IS CLIENT SECTION 
### THIS SECTION CONTAINS THE WAC CLIENT SIDE FUNCTIONS 
 If (!([double]::TryParse($iss2d, [ref]$null)))  {

 Clear-host
 Write-host "Beggining WAC logic. We Detected this is not a cluster and if this is a Wac machine, an analysis begins now..."
 $theirclusterNAME = read-host  " Please confirm the CLuster name and then enter:"
#$mywacin= (wmic product where "Name='Windows Admin Center'" get IdentifyingNumber | Select-String -Pattern '{.*}').Line.Trim()
$answac= (get-childitem HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\* | get-itemproperty | where { $_ -match 'Windows admin center' })

  
if ($answac.DisplayName -eq "Windows Admin Center")
{


Function ripWac {
# checking to see if was is winrm over http and will rip and reinstall wac
# this will not handle the case where the customer went and did winrm RBAC- the cusotmer is on his own with this hardening 
[bool]$ripwacvar = $true
[bool] $mywinrmhttps = $false
try {
    $result = Get-WSManInstance -ResourceUri WinRM/Config/Listener -SelectorSet @{Address = "*"; Transport = "HTTPS"} -ErrorAction SilentlyContinue
 [bool] $mywinrmhttps = $true

} catch {
    if ($_.Exception.Message -like "*The client cannot connect to the destination specified in the request.*") {
      [bool] $mywinrmhttps = $false
       
       }
}

If ($mywinrmhttps -eq $true)
{
Write-host "A significant event has been found. WinRm over HTTPS is complex and beyond the scope of current Setup"
Write-host " We well remove and reinstall Wac, but having setup WIn RM over HTTPS, it will be your responsiblilty to remove all elements if this fails."
$message= read-host " You are being warned. your Wac install is Winrm over Https and will be removed immediately. If you Hit a key and enter a process to reinstall Wac begings"
 

Remove-Item -Path WSMan:\localhost\Listener\Listener* -Include "HTTPS" -Force  -ErrorAction SilentlyContinue
Get-ChildItem Cert:\LocalMachine\My | Where-Object {$_.Subject -like "*CN=WinRM*"} | Remove-Item
Set-Item -Path WSMan:\localhost\Service\Auth\CredSSP -Value $False
#Start-Process msiexec.exe -Wait -ArgumentList "/u
 #$mywacin= (wmic product where "Name='Windows Admin Center'" get IdentifyingNumber | Select-String -Pattern '{.*}').Line.Trim()
 #msiexec /x $mywacin /qn
  (Get-WmiObject -Class Win32_Product -Filter "Name = 'Windows Admin Center'").uninstall()
[bool] $ripwacvar= $false


read-host "Wait a few minutes and hit enter. This will do a clean intall once you hit enter"

netsh http delete sslcert ipport=0.0.0.0:443
netsh http delete urlacl url=https://+:443/

#if something goes wrong removing wac you may have to remove with local cert store and winrm listener
#certutil -store my
#certutil -delstore my XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

Invoke-WebRequest -UseBasicParsing -Uri https://aka.ms/WACDownload -OutFile "$env:USERPROFILE\Downloads\WindowsAdminCenter.msi"

   Start-Process msiexec.exe -Wait -ArgumentList "/i $env:USERPROFILE\Downloads\WindowsAdminCenter.msi /qn /L*v waclog.txt REGISTRY_REDIRECT_PORT_80=1 SME_PORT=443 SSL_CERTIFICATE_OPTION=generate"
   Add-LocalGroupMember -Group "Windows Admin Center CredSSP Administrators" -Member $env:USERDOMAIN\$Env:Username -ErrorAction SilentlyContinue
 Add-LocalGroupMember -Group  "administrators" -Member $env:USERDOMAIN\$Env:Username -ErrorAction SilentlyContinue
$ripwacvar = $true

}
 
Add-LocalGroupMember -Group "Windows Admin Center CredSSP Administrators" -Member $env:USERDOMAIN\$Env:Username -ErrorAction SilentlyContinue 
 Add-LocalGroupMember -Group  "administrators" -Member $env:USERDOMAIN\$Env:Username -ErrorAction SilentlyContinue


 
}  
Function ClientUacheck {

#Allow Remote UAC disable - all nodes 

#$mynodes = $myspanse | Get-ClusterNode

 


REG ADD HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v LocalAccountTokenFilterPolicy /t REG_DWORD /d 1 /f 

 # Create new items with values
 try
 {
New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name  'LocalAccountTokenFilterPolicy' -Value '1' -PropertyType 'DWORD' –Force} Catch {write-host "already added localtoken filter policy" -ForegroundColor Green}

#other Credentials issues dealt with here 

Set-Executionpolicy -executionpolicy remotesigned -Force
Set-Item WSMan:\localhost\Client\TrustedHosts * -Force
 

Enable-WSManCredSSP -Role Client -Delegate $env:USERDNSDOMAIN -force
Enable-WSManCredSSP -Role Server -Force
Set-Item -Path WSMan:\localhost\MaxEnvelopeSizekb 8192 -Force
Try {
New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name AllowFreshCredentialsWhenNTLMOnly -Force}Catch {write-host "no Ntlm Policy My already be in place" -ForegroundColor Green}
try {
(New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name 1 -Value * -PropertyType String -Force) } Catch {write-host "no Ntlm Policy My already be in place" -ForegroundColor Green}


}

Function Clearcache {

 # Clear %temp% folder
Set-location $env:temp
try {Remove-Item -Path "$env:temp\*" -Recurse -Force -ErrorAction SilentlyContinue -WarningAction SilentlyContinue -ErrorVariable $errorvar}
Catch {$errorvar}

# Check if Microsoft Edge is installed
$edgeInstalled = $false
if (Test-Path "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") {
    $edgeInstalled = $true
}

# Clear browser cache
if ($edgeInstalled)
{
    Remove-Item -Path "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\Cache\*" -Recurse -Force -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
    Write-Output "Cleared cache for Microsoft Edge."
}
else
{
    Remove-Item -Path "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Cache\*" -Recurse -Force -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
    Write-Output "Cleared cache for Google Chrome."
}

Write-Output "Cleared cache for $browser and %temp% folder."



}

Function Getfiles{

<#

use this to comment out the getfiles section if needed

#>

Set-Location -Path $Env:Userprofile
$readme1 = read-host "Get needed files? Y or N" 
If( $readme1 -eq "y" )
{
[bool] $files4drac = $true


Try {
                                Write-Host "Downloading ISM..." 
                                Invoke-WebRequest -UseBasicParsing -Uri 'https://dl.dell.com/FOLDER07508105M/1/OM-iSM-Dell-Web-X64-4.1.0.0-2410_A00.exe' -OutFile "$Env:Userprofile\Downloads\isminstall.exe" -ErrorAction SilentlyContinue -ErrorVariable ISMDownloadFailed }
    Catch{Write-Host "ERROR: ISM download failed. $ISMDownloadFailed" -ForegroundColor Red}
                                
try {Write-host "downloading Racadm..."

 # alternate link https://dl.dell.com/FOLDER05171522M/1/OM-DRAC-Dell-Web-WINX64-9.2.0-3142_A00.exe          
  Invoke-WebRequest -UseBasicParsing -Uri 'https://downloads.dell.com/FOLDER07549599M/1/DellEMC-iDRACTools-Web-WINX64-10.2.0.0-4583_A00.exe' -OutFile "$Env:Userprofile\downloads\racadmininstall.exe" -ErrorAction SilentlyContinue -ErrorVariable RACAdminDownloadFailed } Catch{ Write-Host "ERROR: $RACAdminDownloadFailed RACAdmin Tools download failed." -ForegroundColor Red    }        
  
  [bool] $megetfiles= $true


          
}

if ($readme1 -ne "y")
{
[bool] $files4drac = $false
$megetfiles = $false 

}

}


ripwac
 If ($mywinrmhttps -eq $true)  {
 Write-Host " ✘Failure Fixing WAC permissions " -ForegroundColor red} else {
 Write-Host "✔ Finished Fixing wac permissions" -ForegroundColor green} 
 

If (ClientUacheck) {
 Write-Host "✔ Finished Adding Client Rules" -ForegroundColor Green   } else {
 Write-Host "✘ Failure Adding Client Rules" -ForegroundColor Red   } 

 If (clearcache) {
 Write-Host "✔ Finished Clearing the WAC Cache" -ForegroundColor Green   } else {
 Write-Host "✘ Failure Clearing the WAC Cache" -ForegroundColor Red   } 

 

 getfiles
   If ($files4drac) {
 Write-Host "✔ Finished Getting files download idractool and ism" -ForegroundColor Green   }  

  If (!$files4drac) {
 Write-Host "✔ Finished you chose not to Get files download idractool and ism" -ForegroundColor Green   }  

}

[bool] $finished= $true

if ($finished){
 Write-Host "✔ Finished up with script Succeed" -ForegroundColor Green   } else {
 Write-Host "✘ Failure Repair - Take a Screenshot and troubleshoot" -ForegroundColor Red   } 


 #if ($megetfiles -eq $true)

 $mygetfiles=  read-host "Copy the Racadmininstall.exe and ISMinstall.exe to the download folder on all cluster servers? y/n"
If ($mygetfiles -like 'y'){

 $mysourceshare = "\\$env:computername\c$\users\$env:USERNAME\downloads\"  


 Invoke-Command -ComputerName ((Get-ClusterNode -Cluster (Get-Cluster $theirclusterNAME))).name -ScriptBlock { 
  
   $myhost= $env:computername
$mynodeshare = "\\$env:computername\c$\users\$env:USERNAME\downloads\"

Copy-Item -Path "$using:mysourceshare\isminstall.exe" -Destination $mynodeshare\isminstall.exe -Recurse -Force  -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
Copy-Item -Path "$using:mysourceshare\racadmininstall.exe" -Destination $mynodeshare\racadmininstall.exe -Recurse -Force -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
}
}

 Add-LocalGroupMember -Group "Windows Admin Center CredSSP Administrators" -Member $env:USERDOMAIN\$Env:Username -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
 Add-LocalGroupMember -Group  "administrators" -Member $env:USERDOMAIN\$Env:Username -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
 Add-LocalGroupMember -Group  "Windows Admin Center CredSSP Administrators" -Member "Domain Admins" -ErrorAction SilentlyContinue -WarningAction SilentlyContinue

 
  If($SetupServer) {
 Write-Host "✔ Finished Copy Drac tools ism to CLuster " -ForegroundColor Green} else {
 Write-Host "✘ Failure may mean the files are already Copied to CLuster" -ForegroundColor Green} 


 Write-host "------------Final checks Function confirmed ------------------" -ForegroundColor Green

 set-location "C:\Program Files\Dell\SysMgt\iDRACTools\racadm\"
    .\racadm.exe set idrac.servicemodule.osinfo 1           
            .\racadm get idrac.os-bmc.adminstate
            .\racadm.exe set idrac.servicemodule.ServiceModuleEnable 1
            stop-Service -Name msiserver


 }
 $SetupServer = $true 













 