﻿#########################
#
#       WRNS tool
#       WAC Really NEEDED Stuff (WE really Need Support) (WRNS)
#
#
#
#
########################################################
# its reccomeneded to shut the firewall profiles with source and target if your having peoblems - turn them on after##

The Racadm Commands are supposed to run in CMD. you can run in powershell with the .\ but its not 100% reliable- depending on the command

##Begin PowerShell Script – Paste this in ISE PowerShell##
$a= Read-Host “what is the full domain name?”
$str1="*" 
$ans1= $str1+"."+$a
$ans1 
#Fix target machines

#these are for troubleshooting if you need to go back to run racadm 
#set-location "c:\program files\dell\sysmgt\idractools\racadm\" -PassThru
#set-location "c:\openmanage\"

#.\racadm get idrac.servicemodule 
#start-service -Name "iDRAC Service Module"
# invoke-WebRequest -UseBasicParsing -Uri https://dl.dell.com/FOLDER08068411M/1/OM-iSM-Dell-Web-X64-4.2.0.0-2581_A00.exe -outfile c:\openmanage\ism4.2.exe
#set-location "c:\program files\dell\sysmgt\idractools\racadm\" -PassThru
#netsh advfirewall set allprofiles state off
Set-NetFirewallRule -Name WINRM-HTTP-In-TCP-PUBLIC -RemoteAddress Any 
# for NVME failed disks – reset-physicaldisk -serialnumber xxxxx
Set-Executionpolicy -executionpolicy remotesigned 
Set-Item WSMan:\localhost\Client\TrustedHosts *
Enable-WSManCredSSP -Role Client -Delegate $ans1
Enable-WSManCredSSP -Role Server
Set-Item -Path WSMan:\localhost\MaxEnvelopeSizekb 8192
##End PowerShell Script – Paste this in ISE PowerShell##
##Begin Batch file or run in CMD as admin##
##Open a command windows and navigate to C:\Program Files\Dell\SysMgt\idractools\racadm
# REG ADD HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v LocalAccountTokenFilterPolicy /t REG_DWORD /d 1

 # Create new items with values
New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name  'LocalAccountTokenFilterPolicy' -Value '1' -PropertyType 'DWORD' –Force
# Get out of the Registry
Pop-Location

set-location "c:\program files\dell\sysmgt\idractools\racadm\" -PassThru
.\racadm set idrac.os-bmc.adminstate 1
.\racadm set iDRAC.WebServer.HostHeaderCheck Disabled
.\racadm set LifeCycleController.LCAttributes.LifecycleControllerState 1
.\racadm closessn –u AzSHCIAdmin
# n45d5 if your using drac8 – check the sessions tab to make sure racadm closessn –u n45d5
.\Racadm set idrac.OS-BMC.PTMode 1
 
## End ###
#Run these commands on the WAC server. 
 
##Begin PowerShell Script – Paste this in ISE PowerShell##
#$a= Read-Host “what is the full domain name?”
#$str1="*" 
#$ans1= $str1+"."+$a
#$ans1 
#fix source machines
#Set-Executionpolicy -executionpolicy unrestricted 
#Set-Item WSMan:\localhost\Client\TrustedHosts *
#Enable-WSManCredSSP -Role Client -Delegate $ans1
#Enable-WSManCredSSP -Role Server
#Set-Item -Path WSMan:\localhost\MaxEnvelopeSizekb 8192
##End PowerShell Script – Paste this in ISE PowerShell##


Install Windows Admin Center 
