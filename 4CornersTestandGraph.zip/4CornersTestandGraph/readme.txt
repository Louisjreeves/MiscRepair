Graph 4 corners Drive Speed test and graph

What you get in this package

#1 Diskspd and instructions to run script to collect a test data of drive speed in 4 block sizes 
#2 Three Scripts that each output a png graph, an output graph to the screen and a json file of output data. 
#3 Sample csv Data file that shows the exact column names needed for the script to work


Technical data 

•	Random read and write is graphed for IOPS in RandomOnly_IOPS.ps1
•	Sequential read and write are graphed for MB/Sec in Seq_ThroughputOnly.ps1
•	Both are graphed in GraphCsvALL.ps1
